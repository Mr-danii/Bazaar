from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timezone

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    role = db.Column(db.String(10), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)

    # Setter for password (hashing the password)
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    # Verifying the password
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(100), nullable=False)
    product_description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    sku = db.Column(db.String(50), unique=True, nullable=False)
    price = db.Column(db.Float, nullable=False)
    stock_quantity = db.Column(db.Integer, nullable=False)
    stock_status = db.Column(db.String(20), nullable=False)
    main_image = db.Column(db.String(255))
    additional_image1 = db.Column(db.String(255))
    additional_image2 = db.Column(db.String(255))
    additional_image3 = db.Column(db.String(255))
    product_video = db.Column(db.String(255))
    shipping_methods = db.Column(db.String(255))
    delivery_time = db.Column(db.String(50))
    variant_type1 = db.Column(db.String(50))
    variant_values1 = db.Column(db.String(255))
    return_policy = db.Column(db.Text)

    # Add a foreign key to track which user uploaded the product
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    # Relationship with User model
    user = db.relationship('User', backref=db.backref('products', lazy=True))
    
    def __repr__(self):
        return f"<Product {self.product_name}>"
    
class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    
    # Foreign key to the User who owns the cart item
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Foreign key to the Product added to the cart
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    
    # Quantity of the product
    quantity = db.Column(db.Integer, default=1, nullable=False)
    
    # Timestamp for when the item was added (optional but helpful)
    date_added = db.Column(db.DateTime, server_default=db.func.now())
    
    # Optional: track variant selection if your site uses variants
    selected_variant = db.Column(db.String(100), nullable=True)

    # Relationships
    user = db.relationship('User', backref=db.backref('cart_items', lazy=True))
    product = db.relationship('Product', backref=db.backref('cart_entries', lazy=True))

    def __repr__(self):
        return f"<Cart User: {self.user_id}, Product: {self.product_id}, Qty: {self.quantity}>"

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    
    quantity = db.Column(db.Integer, nullable=False)
    selected_variant = db.Column(db.String(100), nullable=True)
    payment_method = db.Column(db.String(50), nullable=False)  # e.g., 'Cash on Delivery'
    
    state = db.Column(db.String(20), default='Pending')  # Can be: Pending, Processing, Shipped, Delivered, Canceled, Returned
    order_date = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

    # Relationships
    user = db.relationship('User', backref=db.backref('orders', lazy=True))
    product = db.relationship('Product', backref=db.backref('orders', lazy=True))

    def __repr__(self):
        return f"<Order User: {self.user_id}, Product: {self.product_id}, State: {self.state}>"

class Review(db.Model):
    __tablename__ = 'reviews'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = db.relationship('User', backref=db.backref('reviews', lazy=True))
    product = db.relationship('Product', backref=db.backref('reviews', lazy=True))
    order = db.relationship('Order', backref=db.backref('reviews', lazy=True))
    replies = db.relationship('ReviewReply', backref='review', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Review {self.id}>'

class ReviewReply(db.Model):
    __tablename__ = 'review_replies'
    
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, db.ForeignKey('reviews.id'), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    reply_text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    seller = db.relationship('User', backref=db.backref('review_replies', lazy=True))

    def __repr__(self):
        return f'<ReviewReply {self.id}>'

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)

    # Relationships
    sender = db.relationship('User', foreign_keys=[sender_id], backref='sent_messages')
    receiver = db.relationship('User', foreign_keys=[receiver_id], backref='received_messages')
    order = db.relationship('Order', backref='messages')
