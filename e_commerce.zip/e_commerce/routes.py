from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from models import db, User, Product, Cart, Order, Review, ReviewReply, Message
from datetime import datetime, timezone
import os
from sqlalchemy.sql import func
from sqlalchemy.exc import IntegrityError

def create_app():
    app = Flask(__name__)

    # Configurations
    app.secret_key = "b7d8f9e4c3a1d6f2e9b5a7c8d1e3f4g6"
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize the database
    db.init_app(app)

    with app.app_context():
        db.create_all()

    @app.route('/api/check-session')
    def check_session():
        print("Checking session...")
        print("Session data:", session)
        if 'user_id' in session:
            return jsonify({
                'success': True,
                'user_id': session['user_id'],
                'role': session.get('role', 'unknown')
            })
        return jsonify({
            'success': False,
            'error': 'No active session'
        })

    # Home route
    @app.route('/')
    def home():
        return render_template('index.html')

    # Login route
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            email = request.form['email']
            password = request.form['password']

            # Check for admin credentials first
            if email == 'zero@gmail.com' and password == 'zerozero1@A':
                session['user_id'] = 0  # Special ID for admin
                session['role'] = 'admin'
                flash('Admin login successful!', 'success')
                return redirect(url_for('admin_dashboard'))

            user = User.query.filter_by(email=email).first()
            if user and user.check_password(password):
                session['user_id'] = user.id
                session['role'] = user.role
                # flash('Login successful!', 'success')

                # Redirect based on user role
                if user.role == 'buyer':
                    return redirect(url_for('buyer_dashboard'))
                elif user.role == 'seller':
                    return redirect(url_for('seller_dashboard'))
                else:
                    flash('Invalid role.', 'danger')
                    return redirect(url_for('login'))

            else:
                flash('Invalid email or password', 'danger')

        return render_template('login.html')

    # Buyer Dashboard
    @app.route('/buyer')
    def buyer_dashboard():
        if session.get('role') == 'buyer':
            return render_template('buyer.html')
        flash('Access denied!', 'danger')
        return redirect(url_for('login'))

    # Seller Dashboard
    @app.route('/seller')
    def seller_dashboard():
        if session.get('role') == 'seller':
            return render_template('seller.html')
        flash('Access denied!', 'danger')
        return redirect(url_for('login'))

    # Signup route
    @app.route('/signup', methods=['GET', 'POST'])
    def signup():
        if request.method == 'POST':
            role = request.form['role']
            name = request.form['name']
            email = request.form['email']
            phone = request.form['phone']
            address = request.form['address']
            password = request.form['password']

            existing_user = User.query.filter_by(email=email).first()
            if existing_user:
                flash('Email already registered. Please login.', 'danger')
                return redirect(url_for('login'))

            new_user = User(role=role, name=name, email=email, phone=phone, address=address)
            new_user.set_password(password)  # Hashing password
            db.session.add(new_user)
            db.session.commit()

            flash('Signup successful! Please login.', 'success')
            return redirect(url_for('login'))

        return render_template('signup.html')

    # About Us route
    # @app.route('/about')
    # def about():
    #     return render_template('about.html')

    # Contact Us route
    # @app.route('/contact')
    # def contact():
    #     return render_template('contact.html')
    
    @app.route('/messages')
    def messages():
        return render_template('messages.html')

    @app.route('/cart')
    def cart():
        return render_template('cart.html')

    @app.route('/my-orders')
    def my_orders():
        return render_template('myorders.html')
    
    
    @app.route('/orders')
    def view_orders():
        return render_template('vieworders.html')

    @app.route('/add-product')
    def add_product():
        return render_template('addproduct.html')

    # @app.route('/messages')  # Disabled
    # def received_messages():
    #     return render_template('recievedmesseges.html')

    @app.route('/review')
    def review():
        if 'user_id' not in session:
            flash('Please login to view reviews.', 'danger')
            return redirect(url_for('login'))

        # Get all products for the current seller
        products = Product.query.filter_by(user_id=session['user_id']).all()
        
        # Get reviews for each product
        products_with_reviews = []
        for product in products:
            reviews = Review.query.filter_by(product_id=product.id).all()
            products_with_reviews.append({
                'product': product,
                'reviews': reviews
            })
        
        return render_template('review.html', products_with_reviews=products_with_reviews)

    @app.route('/my-shop')
    def my_shop():
        return render_template('shop-seller.html')

    # Logout route
    @app.route('/logout')
    def logout():
        session.pop('user_id', None)
        session.pop('role', None)
        # flash('Logged out successfully.', 'info')
        return redirect(url_for('login'))
    
    
    
    
    # ________________________________________________product__________________________________________
    
    UPLOAD_FOLDER = 'static/uploads'
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    @app.route('/post-product', methods=['POST'])   
    def post_product():
       if request.method == 'POST':
           if 'user_id' not in session:
               flash('You must be logged in to add a product.', 'danger')
               return redirect(url_for('login'))

           user_id = session['user_id']  # Get logged-in user ID

           # Basic Information
           product_name = request.form.get('product_name')
           description = request.form.get('product_description')
           category = request.form.get('category')
           sku = request.form.get('sku')

           # Pricing & Inventory
           price = request.form.get('price')
           stock_quantity = request.form.get('stock_quantity')
           stock_status = request.form.get('stock_status')

           # Media (File Uploads)
           main_image = request.files.get('main_image')
           additional_image1 = request.files.get('additional_image1')
           additional_image2 = request.files.get('additional_image2')
           additional_image3 = request.files.get('additional_image3')
           product_video = request.files.get('product_video')

           # Shipping & Delivery
           shipping_methods = request.form.getlist('shipping_methods')
           delivery_time = request.form.get('delivery_time')

           # Variants & Options
           variant_type1 = request.form.get('variant_type1')
           variant_values1 = request.form.get('variant_values1')

           # Return Policy
           return_policy = request.form.get('return_policy')

           # Validate required fields
           if not all([product_name, description, category, sku, price, stock_quantity, stock_status, return_policy, delivery_time]):
               return "All required fields must be provided.", 400

           # Convert shipping methods list to a string
           shipping_methods_str = ','.join(shipping_methods)

           # Save uploaded files if they exist
           image1_path = f"{UPLOAD_FOLDER}/{main_image.filename}" if main_image and main_image.filename else None
           image2_path = f"{UPLOAD_FOLDER}/{additional_image1.filename}" if additional_image1 and additional_image1.filename else None
           image3_path = f"{UPLOAD_FOLDER}/{additional_image2.filename}" if additional_image2 and additional_image2.filename else None
           image4_path = f"{UPLOAD_FOLDER}/{additional_image3.filename}" if additional_image3 and additional_image3.filename else None
           video_path = f"{UPLOAD_FOLDER}/{product_video.filename}" if product_video and product_video.filename else None

           # Save files
           if main_image:
               main_image.save(image1_path)
           if additional_image1:
               additional_image1.save(image2_path)
           if additional_image2:
               additional_image2.save(image3_path)
           if additional_image3:
               additional_image3.save(image4_path)
           if product_video:
               product_video.save(video_path)

           # Create a new product instance
           new_product = Product(
               product_name=product_name,
               product_description=description,
               category=category,
               sku=sku,
               price=float(price),
               stock_quantity=stock_quantity,
               stock_status=stock_status,
               main_image=image1_path,
               additional_image1=image2_path,
               additional_image2=image3_path,
               additional_image3=image4_path,
               product_video=video_path,
               shipping_methods=shipping_methods_str,
               delivery_time=delivery_time,
               variant_type1=variant_type1,
               variant_values1=variant_values1,
               return_policy=return_policy,
               user_id=user_id  # Store user ID
           )

           # Save to database
           db.session.add(new_product)
           try:
               db.session.commit()
               return jsonify({
                   'success': True,
                   'message': 'Product added successfully!',
                   'redirect': url_for('add_product')
               })
           except IntegrityError as e:
               db.session.rollback()
               if 'UNIQUE constraint failed: product.sku' in str(e.orig):
                   return jsonify({
                       'success': False,
                       'error': 'SKU already exists. Please use a different SKU.',
                       'showDialog': True
                   }), 400
               else:
                   return jsonify({
                       'success': False,
                       'error': 'An error occurred while adding the product.',
                       'showDialog': True
                   }), 400

       return render_template('addproduct.html')


    @app.route('/api/products', methods=['GET'])
    def get_products():
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({"error": "Unauthorized"}), 401

        products = Product.query.filter_by(user_id=user_id).all()
        
        if not products:
            return jsonify({"message": "No products found"}), 200  # Return empty but valid response

        products_list = [
            {
                "id": product.id,
                "name": product.product_name,
                "description": product.product_description,
                "price": product.price,
                "stock": product.stock_quantity,
                "status": product.stock_status,
                "main_image": product.main_image or "static/images/default-product.jpg"
            }
            for product in products
        ]

        return jsonify(products_list)

    @app.route('/api/products/<int:product_id>', methods=['DELETE'])
    def delete_product(product_id):
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({"error": "Unauthorized"}), 401  # Ensure the user is logged in

        product = Product.query.get(product_id)
        if not product:
            return jsonify({"error": "Product not found"}), 404

        # Ensure the logged-in user is the owner of the product
        if product.user_id != user_id:
            return jsonify({"error": "Permission denied"}), 403

        db.session.delete(product)
        db.session.commit()

        return jsonify({"message": "Product deleted successfully"}), 200
    

    @app.route('/api/products/<int:product_id>', methods=['PUT'])   
    def update_product(product_id):
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({"error": "Unauthorized"}), 401  # Ensure the user is logged in

        product = Product.query.get(product_id)
        if not product:
            return jsonify({"error": "Product not found"}), 404

        # Ensure the logged-in user is the owner of the product
        if product.user_id != user_id:
            return jsonify({"error": "Permission denied"}), 403

        data = request.json  # Get JSON data from frontend

        # Update only the provided fields
        product.product_name = data.get("name", product.product_name)
        product.price = data.get("price", product.price)
        product.stock_quantity = data.get("stock", product.stock_quantity)

        db.session.commit()  # Save changes

        return jsonify({
            "message": "Product updated successfully",
            "product": {
                "id": product.id,
                "name": product.product_name,
                "price": product.price,
                "stock": product.stock_quantity
            }
        }), 200

# ____________all products ___________________



    @app.route('/api/all-products', methods=['GET'])
    def get_all_products():
        # Query products with average ratings
        products_with_ratings = db.session.query(
            Product,
            db.func.avg(Review.rating).label('avg_rating'),
            db.func.count(Review.id).label('review_count')
        ).outerjoin(
            Review, Product.id == Review.product_id
        ).group_by(
            Product.id
        ).all()
        
        # Format the results
        products_list = []
        for product, avg_rating, review_count in products_with_ratings:
            # Get the user (seller) information
            seller = User.query.get(product.user_id)
            
            product_dict = {
                "id": product.id,
                "product_name": product.product_name,
                "product_description": product.product_description,
                "category": product.category,
                "sku": product.sku,
                "price": float(product.price),
                "stock_quantity": product.stock_quantity,
                "stock_status": product.stock_status,
                "main_image": product.main_image or "static/images/default-product.jpg",
                "additional_image1": product.additional_image1,
                "additional_image2": product.additional_image2,
                "additional_image3": product.additional_image3,
                "product_video": product.product_video,
                "shipping_methods": product.shipping_methods,
                "delivery_time": product.delivery_time,
                "variant_type1": product.variant_type1,
                "variant_values1": product.variant_values1,
                "return_policy": product.return_policy,
                "user_id": product.user_id,
                "seller_name": seller.name if seller else "Unknown",
                "seller_email": seller.email if seller else "",
                "avg_rating": float(avg_rating) if avg_rating else 0,
                "review_count": review_count
            }
            products_list.append(product_dict)

        return jsonify(products_list), 200
    
    # add to cart
    
    @app.route('/add-to-cart', methods=['POST'])
    def add_to_cart():
        if 'user_id' not in session:
            return jsonify({"error": "Unauthorized"}), 401

        data = request.get_json()
        product_id = data.get('product_id')
        quantity = data.get('quantity', 1)

        if not product_id:
            return jsonify({"error": "Product ID is required"}), 400

        existing_item = Cart.query.filter_by(user_id=session['user_id'], product_id=product_id).first()

        if existing_item:
            existing_item.quantity += quantity
        else:
            new_item = Cart(
                user_id=session['user_id'],
                product_id=product_id,
                quantity=quantity
            )
            db.session.add(new_item)

        db.session.commit()

        return jsonify({"message": "Product added to cart successfully"}), 200
    
    
    # get cart details

    @app.route('/api/cart-details', methods=['GET'])
    def get_cart_details():
        if 'user_id' not in session:
            return jsonify({"error": "Unauthorized"}), 401

        user_id = session.get('user_id')
        # user_id = 3
        print(f"User ID from session: {user_id}")
        cart_items = Cart.query.filter_by(user_id=user_id).all()

        if not cart_items:
            return jsonify({"message": "Cart is empty "}), 200

        items = []
        cart_total = 0

        for item in cart_items:
            product = Product.query.get(item.product_id)
            if not product:
                continue  # skip if product no longer exists

            seller = User.query.get(product.user_id)
            total_price = float(product.price) * item.quantity
            cart_total += total_price

            items.append({
                "cart_id": item.id,
                "product_id": product.id,
                "name": product.product_name,
                "image": product.main_image or "static/images/default-product.jpg",
                "price": float(product.price),
                "quantity": item.quantity,
                "total_price": total_price,
                "seller_name": seller.name if seller else "Unknown"
            })

        return jsonify({
            "cart_items": items,
            "cart_count": len(items),
            "cart_total": cart_total
        }), 200


# Route to remove a cart entry
    @app.route('/api/remove-cart-entry/<int:item_id>', methods=['DELETE'])
    def remove_cart_entry(item_id):
    # Find the cart item in the database by its ID
        cart_item = Cart.query.get(item_id)
    
        if cart_item is None:
        # If no cart item is found with the provided ID, return an error
            return jsonify({"error": "entry not found"}), 404
    
    # Remove the cart item
        db.session.delete(cart_item)
        db.session.commit()

        return jsonify({'success': True, 'message': 'Cart entry removed successfully'})
    
    @app.route('/place-order', methods=['POST'])
    def place_order():
        user_id = session.get('user_id')  # Or session['id'] depending on how you store session

        if not user_id:
            print("User not logged in.")
            return jsonify({'error': 'User not logged in'}), 401

        cart_items = Cart.query.filter_by(user_id=user_id).all()

        if not cart_items:
            print("Cart is empty.")
            return jsonify({'error': 'Cart is empty'}), 400

        # Get payment method from request data
        data = request.get_json()
        payment_method = data.get('payment_method', 'Cash on Delivery')  # Default to COD if not specified

        for item in cart_items:
            new_order = Order(
                user_id=user_id,
                product_id=item.product_id,
                quantity=item.quantity,
                selected_variant=item.selected_variant,
                payment_method=payment_method,  # Use the payment method from request
                state='Pending',
                order_date=datetime.now(timezone.utc)
            )
            db.session.add(new_order)

        # Delete all cart items after placing order
        Cart.query.filter_by(user_id=user_id).delete()
        db.session.commit()
        print("Order placed successfully for user:", user_id)

        return jsonify({'success': True, 'message': 'Order placed successfully!'}), 200
    
    
    @app.route('/get-my-orders', methods=['GET'])
    def get_my_orders():
        user_id = session.get('user_id')
        print(f"Getting orders for user_id: {user_id}")  # Debug log

        if not user_id:
            return jsonify({'error': 'User not logged in'}), 401

        orders = Order.query.filter_by(user_id=user_id).order_by(Order.order_date.desc()).all()
        print(f"Found {len(orders)} orders")  # Debug log

        order_list = []
        for order in orders:
            product = Product.query.get(order.product_id)
            print(f"Processing order {order.id}, product: {product.product_name if product else 'Unknown'}")  # Debug log
            
            review = Review.query.filter_by(order_id=order.id).first()
            review_data = None
            
            if review:
                review_data = {
                    'id': review.id,
                    'rating': review.rating,
                    'comment': review.comment,
                    'created_at': review.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                    'replies': [{
                        'id': reply.id,
                        'text': reply.reply_text,
                        'created_at': reply.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                        'seller_name': reply.seller.name
                    } for reply in review.replies]
                }

            seller_id = product.user_id if product else None
            print(f"Order {order.id} seller_id: {seller_id}")  # Debug log

            order_data = {
                'order_id': order.id,
                'product_id': order.product_id,
                'product_name': product.product_name if product else 'Unknown',
                'image_01': product.main_image if product else 'Unknown',
                'quantity': order.quantity,
                'variant': order.selected_variant,
                'payment_method': order.payment_method,
                'state': order.state,
                'order_date': order.order_date.strftime('%Y-%m-%d %H:%M:%S'),
                'review': review_data,
                'seller_id': seller_id
            }
            print(f"Order data: {order_data}")  # Debug log
            order_list.append(order_data)
            
        return jsonify({'success': True, 'orders': order_list}), 200
    
    @app.route('/get-orders-for-my-products', methods=['GET'])
    def get_orders_for_my_products():
        user_id = session.get('user_id')

        if not user_id:
            return jsonify({'error': 'User not logged in'}), 401

    # Step 1: Get all products for this user
        products = Product.query.filter_by(user_id=user_id).all()
        product_ids = [product.id for product in products]

        if not product_ids:
            return jsonify({'success': True, 'orders': []}), 200  # No products, no orders

    # Step 2: Get all orders for those product_ids
        orders = Order.query.filter(Order.product_id.in_(product_ids)).order_by(Order.order_date.desc()).all()

    # Step 3: Prepare the response
        order_list = []
        for order in orders:
            product = next((p for p in products if p.id == order.product_id), None)
            # Also fetch the buyer's name
            buyer = User.query.get(order.user_id)
            buyer_name = buyer.name if buyer else 'Unknown Buyer'
            
            order_list.append({
                'order_id': order.id,
                'buyer_id': order.user_id, # Add buyer ID here
                'buyer_name': buyer_name, # Add buyer name here
                'product_name': product.product_name if product else 'Unknown',
                'image_01': product.main_image if product else 'Unknown',
                'quantity': order.quantity,
                'variant': order.selected_variant,
                'payment_method': order.payment_method,
                'state': order.state,
                'order_date': order.order_date.strftime('%Y-%m-%d %H:%M:%S')
            })

        print("Final order list:", order_list)  # Console log
        return jsonify({'success': True, 'orders': order_list}), 200

    @app.route('/update-order-state/<int:order_id>', methods=['POST'])
    def update_order_state(order_id):
        if not session.get('user_id'):
            return jsonify({'error': 'User not logged in'}), 401

        order = Order.query.get(order_id)
        if not order:
            return jsonify({'error': 'Order not found'}), 404

        # Get the current state and determine the next state
        current_state = order.state.lower()
        next_state = None

        if current_state == 'pending':
            next_state = 'Processing'
        elif current_state == 'processing':
            next_state = 'Shipping'
        elif current_state == 'shipping':
            next_state = 'Delivered'
            # When marking as delivered, decrease the product quantity
            product = Product.query.get(order.product_id)
            if product:
                if product.stock_quantity >= order.quantity:
                    product.stock_quantity -= order.quantity
                    if product.stock_quantity == 0:
                        product.stock_status = 'Out of Stock'
                    else:
                        product.stock_status = 'In Stock'  # Update stock status if still has items
                else:
                    return jsonify({'error': 'Insufficient stock to mark as delivered'}), 400
        elif current_state == 'delivered':
            return jsonify({'error': 'Order is already delivered'}), 400

        if next_state:
            order.state = next_state
            db.session.commit()
            return jsonify({'success': True, 'message': f'Order state updated to {next_state}'}), 200
        else:
            return jsonify({'error': 'Invalid state transition'}), 400

    @app.route('/cancel-order/<int:order_id>', methods=['POST'])
    def cancel_order(order_id):
        if not session.get('user_id'):
            return jsonify({'error': 'User not logged in'}), 401

        order = Order.query.get(order_id)
        if not order:
            return jsonify({'error': 'Order not found'}), 404

        # Only allow cancellation if order is not already delivered or cancelled
        if order.state.lower() in ['delivered', 'cancelled']:
            return jsonify({'error': 'Cannot cancel this order'}), 400

        order.state = 'Cancelled'
        db.session.commit()
        return jsonify({'success': True, 'message': 'Order cancelled successfully'}), 200

    @app.route('/submit-review', methods=['POST'])
    def submit_review():
        if not session.get('user_id'):
            return jsonify({'error': 'User not logged in'}), 401

        try:
            data = request.get_json()
            order_id = data.get('order_id')
            product_id = data.get('product_id')
            rating = data.get('rating')
            comment = data.get('comment')

            if not all([order_id, product_id, rating]):
                return jsonify({'error': 'Missing required fields'}), 400

            # Check if the order exists and belongs to the current user
            order = Order.query.filter_by(id=order_id, user_id=session['user_id']).first()
            if not order:
                return jsonify({'error': 'Order not found'}), 404

            # Check if the order is delivered
            if order.state != 'Delivered':
                return jsonify({'error': 'Can only review delivered orders'}), 400

            # Check if review already exists for this order
            existing_review = Review.query.filter_by(order_id=order_id).first()
            if existing_review:
                return jsonify({'error': 'Review already submitted for this order'}), 400

            # Create new review
            review = Review(
                user_id=session['user_id'],
                product_id=product_id,
                order_id=order_id,
                rating=rating,
                comment=comment
            )

            db.session.add(review)
            db.session.commit()

            return jsonify({'success': True, 'message': 'Review submitted successfully'}), 200

        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    @app.route('/get-product-reviews/<int:product_id>')
    def get_product_reviews(product_id):
        user_id = session.get('user_id')

        if not user_id:
            return jsonify({'error': 'User not logged in'}), 401        
        try:
            reviews = Review.query.filter_by(product_id=product_id).all()
            reviews_data = [{
                'id': review.id,
                'user_id': review.user_id,
                'rating': review.rating,
                'comment': review.comment,
                'created_at': review.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'user_name': review.user.name if review.user else 'Anonymous'
            } for review in reviews]

            return jsonify({'success': True, 'reviews': reviews_data}), 200

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/submit-review-reply', methods=['POST'])
    def submit_review_reply():
        if not session.get('user_id'):
            return jsonify({'error': 'User not logged in'}), 401

        try:
            data = request.get_json()
            review_id = data.get('review_id')
            reply_text = data.get('reply_text')

            if not all([review_id, reply_text]):
                return jsonify({'error': 'Missing required fields'}), 400

            # Check if the review exists
            review = Review.query.get(review_id)
            if not review:
                return jsonify({'error': 'Review not found'}), 404

            # Check if the current user is the seller of the product
            product = Product.query.get(review.product_id)
            if not product or product.user_id != session['user_id']:
                return jsonify({'error': 'Unauthorized to reply to this review'}), 403

            # Create new reply
            reply = ReviewReply(
                review_id=review_id,
                seller_id=session['user_id'],
                reply_text=reply_text
            )

            db.session.add(reply)
            db.session.commit()

            return jsonify({
                'success': True, 
                'message': 'Reply submitted successfully',
                'reply': {
                    'id': reply.id,
                    'text': reply.reply_text,
                    'created_at': reply.created_at.strftime('%B %d, %Y'),
                    'seller_name': reply.seller.name
                }
            }), 200

        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    @app.route('/api/dashboard-seller-data')
    def dashboard_seller_data():
        print("Dashboard endpoint called")
        print("Session data:", session)
        
        if 'user_id' not in session:
            print("No user_id in session")
            return jsonify({'success': False, 'error': 'Not logged in'}), 401
        
        try:
            user_id = session['user_id']
            print(f"Fetching data for user_id: {user_id}")
            
            # Get seller stats
            try:
                # Get all orders for this seller's products
                products = Product.query.filter_by(user_id=user_id).all()
                product_ids = [p.id for p in products]
                total_orders = Order.query.filter(Order.product_id.in_(product_ids)).count()
                print(f"Total orders: {total_orders}")
            except Exception as e:
                print(f"Error getting total orders: {str(e)}")
                total_orders = 0
            
            try:
                # Calculate total earnings by summing (product price * quantity) for all orders
                total_earnings = 0
                orders = Order.query.filter(Order.product_id.in_(product_ids)).all()
                for order in orders:
                    product = Product.query.get(order.product_id)
                    if product:
                        total_earnings += float(product.price) * order.quantity
                print(f"Total earnings: {total_earnings}")
            except Exception as e:
                print(f"Error getting total earnings: {str(e)}")
                total_earnings = 0
            
            try:
                total_products = Product.query.filter_by(user_id=user_id).count()
                print(f"Total products: {total_products}")
            except Exception as e:
                print(f"Error getting total products: {str(e)}")
                total_products = 0
            
            try:
                # Calculate average rating
                avg_rating = db.session.query(db.func.avg(Review.rating)).filter(
                    Review.product_id.in_(
                        db.session.query(Product.id).filter_by(user_id=user_id)
                    )
                ).scalar() or 0
                print(f"Average rating: {avg_rating}")
            except Exception as e:
                print(f"Error getting average rating: {str(e)}")
                avg_rating = 0
            
            try:
                # Get recent orders (last 5)
                recent_orders = Order.query.filter(Order.product_id.in_(product_ids))\
                    .order_by(Order.order_date.desc())\
                    .limit(5)\
                    .all()
                print(f"Recent orders count: {len(recent_orders)}")
                
                orders_data = []
                for order in recent_orders:
                    try:
                        product = Product.query.get(order.product_id)
                        customer = User.query.get(order.user_id)
                        if product and customer:  # Add null checks
                            total_price = float(product.price) * order.quantity
                            orders_data.append({
                                'order_id': order.id,
                                'product_name': product.product_name,
                                'customer_name': customer.name,
                                'order_date': order.order_date.isoformat() if order.order_date else None,
                                'price': total_price,
                                'state': order.state
                            })
                    except Exception as e:
                        print(f"Error processing order {order.id}: {str(e)}")
                        continue
            except Exception as e:
                print(f"Error getting recent orders: {str(e)}")
                orders_data = []
            
            response_data = {
                'success': True,
                'stats': {
                    'total_orders': total_orders,
                    'total_earnings': float(total_earnings),
                    'total_products': total_products,
                    'avg_rating': float(avg_rating) if avg_rating else 0
                },
                'recent_orders': orders_data
            }
            
            print("Response data:", response_data)
            return jsonify(response_data)
            
        except Exception as e:
            print(f"Error in dashboard_seller_data: {str(e)}")
            import traceback
            print(traceback.format_exc())
            return jsonify({
                'success': False, 
                'error': str(e),
                'traceback': traceback.format_exc()
            }), 500




    @app.route('/api/get-current-user')
    def get_current_user():
        user_id = session.get('user_id')
        if user_id:
            # Get the full user object
            user = User.query.get(user_id)
            if user:
                # Return complete user data
                return jsonify({
                    'success': True, 
                    'user': {
                        'id': user.id,
                        'name': user.name,
                        'email': user.email,
                        'phone': user.phone,
                        'address': user.address,
                        'role': user.role
                    }
                })
            else:
                return jsonify({'success': False, 'error': 'User not found'}), 404
        return jsonify({'success': False, 'error': 'Not logged in'}), 401

    @app.route('/api/random-reviews', methods=['GET'])
    def get_random_reviews():
        try:
            # Get 5 random reviews with user and product information
            reviews = db.session.query(
                Review,
                User.name.label('customer_name'),
                Product.product_name
            ).join(
                User, Review.user_id == User.id
            ).join(
                Product, Review.product_id == Product.id
            ).order_by(
                func.random()
            ).limit(5).all()

            # Format the response
            formatted_reviews = []
            for review, customer_name, product_name in reviews:
                formatted_reviews.append({
                    'customer_name': customer_name,
                    'product_name': product_name,
                    'rating': review.rating,
                    'comment': review.comment
                })

            return jsonify({
                'success': True,
                'reviews': formatted_reviews
            })

        except Exception as e:
            print(f"Error fetching reviews: {str(e)}")
            return jsonify({
                'success': False,
                'error': 'Failed to fetch reviews'
            }), 500

    @app.route('/api/send-message', methods=['POST'])
    def send_message():
        if 'user_id' not in session:
            return jsonify({'error': 'Not logged in'}), 401

        data = request.get_json()
        receiver_id = data.get('receiver_id')
        order_id = data.get('order_id')
        message_text = data.get('message')

        if not all([receiver_id, order_id, message_text]):
            return jsonify({'error': 'Missing required fields'}), 400

        # Verify the order exists 
        order = Order.query.get(order_id)
        if not order:
            return jsonify({'error': 'Order not found'}), 404
            
        # Ensure product relationship is loaded to get seller ID
        if not order.product:
            print(f"Error: Product not found for Order ID {order_id} in send_message")
            return jsonify({'error': 'Product associated with order not found'}), 500

        buyer_id = order.user_id
        seller_id = order.product.user_id
        current_user_id = session['user_id']

        # Check if current user is either the buyer or the seller for this order
        if current_user_id not in [buyer_id, seller_id]:
            print(f"Unauthorized send message attempt: User {current_user_id}, Order {order_id}, Buyer {buyer_id}, Seller {seller_id}")
            return jsonify({'error': 'Unauthorized'}), 403
            
        # Ensure the receiver is the other party (buyer or seller)
        if int(receiver_id) not in [buyer_id, seller_id] or int(receiver_id) == current_user_id:
             print(f"Invalid receiver ID: Receiver {receiver_id}, Current User {current_user_id}, Buyer {buyer_id}, Seller {seller_id}")
             return jsonify({'error': 'Invalid receiver ID'}), 400

        new_message = Message(
            sender_id=current_user_id,
            receiver_id=receiver_id,
            order_id=order_id,
            message=message_text
        )

        db.session.add(new_message)
        db.session.commit()

        return jsonify({
            'success': True,
            'message': {
                'id': new_message.id,
                'sender_id': new_message.sender_id,
                'receiver_id': new_message.receiver_id,
                'message': new_message.message,
                'timestamp': new_message.timestamp.isoformat()
            }
        })

    @app.route('/api/get-messages/<int:order_id>')
    def get_messages(order_id):
        if 'user_id' not in session:
            return jsonify({'error': 'Not logged in'}), 401

        # Verify the order exists and user is part of it
        order = Order.query.get(order_id)
        if not order:
            return jsonify({'error': 'Order not found'}), 404
            
        # Ensure product relationship is loaded to get seller ID
        if not order.product:
             # This should ideally not happen if data integrity is maintained
             # But handle it defensively
            print(f"Error: Product not found for Order ID {order_id}")
            return jsonify({'error': 'Product associated with order not found'}), 500
        
        buyer_id = order.user_id
        seller_id = order.product.user_id
        current_user_id = session['user_id']

        # Check if current user is either the buyer or the seller for this order
        if current_user_id not in [buyer_id, seller_id]:
            print(f"Unauthorized access attempt: User {current_user_id}, Order {order_id}, Buyer {buyer_id}, Seller {seller_id}")
            return jsonify({'error': 'Unauthorized'}), 403

        messages = Message.query.filter_by(order_id=order_id).order_by(Message.timestamp).all()
        
        # Mark unread messages as read
        for message in messages:
            if message.receiver_id == current_user_id and not message.is_read:
                message.is_read = True
        db.session.commit()

        return jsonify({
            'success': True,
            'messages': [{
                'id': msg.id,
                'sender_id': msg.sender_id,
                'receiver_id': msg.receiver_id,
                'message': msg.message,
                'timestamp': msg.timestamp.isoformat(),
                'is_read': msg.is_read
            } for msg in messages]
        })

    @app.route('/api/get-unread-message-count')
    def get_unread_message_count():
        if 'user_id' not in session:
            return jsonify({'error': 'Not logged in'}), 401

        count = Message.query.filter_by(
            receiver_id=session['user_id'],
            is_read=False
        ).count()

        return jsonify({
            'success': True,
            'count': count
        })

    # Admin Dashboard route
    @app.route('/admin/dashboard')
    def admin_dashboard():
        if session.get('role') != 'admin':
            flash('Access denied! Admin access required.', 'danger')
            return redirect(url_for('login'))

        # Fetch statistics
        total_users = User.query.count()
        total_products = Product.query.count()
        total_orders = Order.query.count()
        total_reviews = Review.query.count()
        recent_orders = Order.query.order_by(Order.order_date.desc()).limit(5).all()
        recent_reviews = Review.query.order_by(Review.created_at.desc()).limit(5).all()

        return render_template('admin_dashboard.html',
                             total_users=total_users,
                             total_products=total_products,
                             total_orders=total_orders,
                             total_reviews=total_reviews,
                             recent_orders=recent_orders,
                             recent_reviews=recent_reviews)

    @app.route('/admin/products')
    def admin_products():
        # Fetch all products
        products = Product.query.all()
        return render_template('admin_products.html', products=products)

    @app.route('/admin/users')
    def admin_users():
        return render_template('admin_users.html')

    @app.route('/admin/orders')
    def admin_orders():
        if session.get('role') != 'admin':
            flash('Access denied. Admin privileges required.', 'error')
            return redirect(url_for('index'))
        return render_template('admin_orders.html')

    @app.route('/api/all-orders')
    def get_all_orders():
        print("Debug: Checking session...")
        print("Debug: Session data:", session)
        print("Debug: Session role:", session.get('role'))
        
        if session.get('role') != 'admin':
            print("Debug: Access denied - not admin")
            return jsonify({'error': 'Access denied'}), 403
        
        print("Debug: Access granted - admin role confirmed")
        
        try:
            # Get all orders
            orders = Order.query.all()
            print(f"Debug: Found {len(orders)} orders")
            
            orders_data = []
            for order in orders:
                try:
                    print(f"Debug: Processing order {order.id}")
                    
                    # Get user and product separately
                    user = User.query.get(order.user_id)
                    product = Product.query.get(order.product_id)
                    
                    print(f"Debug: Order {order.id} - User: {user.name if user else 'None'}")
                    print(f"Debug: Order {order.id} - Product: {product.product_name if product else 'None'}")
                    
                    order_data = {
                        'id': order.id,
                        'user': {'name': user.name if user else 'Unknown'},
                        'product': {'product_name': product.product_name if product else 'Unknown'},
                        'quantity': order.quantity,
                        'payment_method': order.payment_method,
                        'state': order.state,
                        'order_date': order.order_date.isoformat()
                    }
                    orders_data.append(order_data)
                except Exception as e:
                    print(f"Debug: Error processing order {order.id}: {str(e)}")
                    print(f"Debug: Order data: {order.__dict__}")
            
            print(f"Debug: Returning {len(orders_data)} orders")
            return jsonify(orders_data)
        except Exception as e:
            print(f"Debug: Error in query: {str(e)}")
            return jsonify({'error': str(e)}), 500

    @app.route('/api/all-orders/<int:order_id>')
    def get_order(order_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        order = Order.query.get_or_404(order_id)
        return jsonify({
            'id': order.id,
            'state': order.state
        })

    @app.route('/admin/orders/edit/<int:order_id>', methods=['POST'])
    def admin_edit_order(order_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        order = Order.query.get_or_404(order_id)
        data = request.get_json()
        
        if 'state' in data:
            order.state = data['state']
            try:
                db.session.commit()
                return jsonify({'success': True})
            except Exception as e:
                db.session.rollback()
                return jsonify({'error': str(e)}), 500
        
        return jsonify({'error': 'Invalid request'}), 400

    @app.route('/admin/orders/delete/<int:order_id>', methods=['POST'])
    def admin_delete_order(order_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        order = Order.query.get_or_404(order_id)
        try:
            db.session.delete(order)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    @app.route('/admin/reviews')
    def admin_reviews():
        if session.get('role') != 'admin':
            flash('Access denied. Admin privileges required.', 'error')
            return redirect(url_for('index'))
        reviews = Review.query.all()
        return render_template('admin_reviews.html', reviews=reviews)

    @app.route('/api/reviews/<int:review_id>')
    def get_review(review_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        review = Review.query.get_or_404(review_id)
        return jsonify({
            'id': review.id,
            'rating': review.rating,
            'comment': review.comment
        })

    @app.route('/admin/reviews/edit/<int:review_id>', methods=['POST'])
    def admin_edit_review(review_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        review = Review.query.get_or_404(review_id)
        data = request.get_json()
        
        if 'rating' in data:
            review.rating = int(data['rating'])
        if 'comment' in data:
            review.comment = data['comment']
        
        try:
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    @app.route('/admin/reviews/delete/<int:review_id>', methods=['POST'])
    def admin_delete_review(review_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        review = Review.query.get_or_404(review_id)
        try:
            db.session.delete(review)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    @app.route('/admin/products/edit/<int:product_id>', methods=['POST'])
    def admin_edit_product(product_id):
        product = Product.query.get_or_404(product_id)
        data = request.get_json() or request.form
        product.product_name = data.get('product_name', product.product_name)
        product.product_description = data.get('product_description', product.product_description)
        product.category = data.get('category', product.category)
        product.sku = data.get('sku', product.sku)
        product.price = float(data.get('price', product.price))
        product.stock_quantity = int(data.get('stock_quantity', product.stock_quantity))
        product.stock_status = data.get('stock_status', product.stock_status)
        product.main_image = data.get('main_image', product.main_image)
        product.additional_image1 = data.get('additional_image1', product.additional_image1)
        product.additional_image2 = data.get('additional_image2', product.additional_image2)
        product.additional_image3 = data.get('additional_image3', product.additional_image3)
        product.product_video = data.get('product_video', product.product_video)
        product.shipping_methods = data.get('shipping_methods', product.shipping_methods)
        product.delivery_time = data.get('delivery_time', product.delivery_time)
        product.variant_type1 = data.get('variant_type1', product.variant_type1)
        product.variant_values1 = data.get('variant_values1', product.variant_values1)
        product.return_policy = data.get('return_policy', product.return_policy)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Product updated successfully.'})

    @app.route('/admin/products/delete/<int:product_id>', methods=['POST'])
    def admin_delete_product(product_id):
        product = Product.query.get_or_404(product_id)
        db.session.delete(product)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Product deleted successfully.'})

    @app.route('/api/all-users', methods=['GET'])
    def get_all_users():
        users = User.query.all()

        if not users:
            return jsonify({"message": "No users found"}), 200

        users_list = [
            {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "phone": user.phone,
                "role": user.role,
                "address": user.address
            }
            for user in users
        ]

        return jsonify(users_list), 200

    @app.route('/admin/users/edit/<int:user_id>', methods=['POST'])
    def admin_edit_user(user_id):
        user = User.query.get_or_404(user_id)
        data = request.get_json() or request.form
        
        # Update user fields
        user.name = data.get('name', user.name)
        user.email = data.get('email', user.email)
        user.phone = data.get('phone', user.phone)
        user.role = data.get('role', user.role)
        user.address = data.get('address', user.address)
        
        db.session.commit()
        return jsonify({'success': True, 'message': 'User updated successfully.'})

    @app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
    def admin_delete_user(user_id):
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        return jsonify({'success': True, 'message': 'User deleted successfully.'})

    @app.route('/api/all-users/<int:user_id>', methods=['GET'])
    def get_user(user_id):
        user = User.query.get_or_404(user_id)
        return jsonify({
            'id': user.id,
            'name': user.name,
            'email': user.email,
            'phone': user.phone,
            'role': user.role,
            'address': user.address
        })

    @app.route('/admin/review-replies')
    def admin_review_replies():
        if session.get('role') != 'admin':
            flash('Access denied. Admin privileges required.', 'error')
            return redirect(url_for('index'))
        replies = ReviewReply.query.all()
        return render_template('admin_review_replies.html', replies=replies)

    @app.route('/api/review-replies/<int:reply_id>')
    def get_review_reply(reply_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        reply = ReviewReply.query.get_or_404(reply_id)
        return jsonify({
            'id': reply.id,
            'reply_text': reply.reply_text
        })

    @app.route('/admin/review-replies/edit/<int:reply_id>', methods=['POST'])
    def admin_edit_review_reply(reply_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        reply = ReviewReply.query.get_or_404(reply_id)
        data = request.get_json()
        
        if 'reply_text' in data:
            reply.reply_text = data['reply_text']
            try:
                db.session.commit()
                return jsonify({'success': True})
            except Exception as e:
                db.session.rollback()
                return jsonify({'error': str(e)}), 500
        
        return jsonify({'error': 'Invalid request'}), 400

    @app.route('/admin/review-replies/delete/<int:reply_id>', methods=['POST'])
    def admin_delete_review_reply(reply_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        reply = ReviewReply.query.get_or_404(reply_id)
        try:
            db.session.delete(reply)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    @app.route('/admin/carts')
    def admin_carts():
        if session.get('role') != 'admin':
            flash('Unauthorized access', 'error')
            return redirect(url_for('login'))
        
        carts = Cart.query.all()
        return render_template('admin_carts.html', carts=carts)

    @app.route('/admin/carts/<int:cart_id>/update-quantity', methods=['POST'])
    def admin_update_cart_quantity(cart_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Unauthorized access'}), 401
        
        cart = Cart.query.get_or_404(cart_id)
        data = request.get_json()
        action = data.get('action')
        
        if action == 'increase':
            cart.quantity += 1
        elif action == 'decrease' and cart.quantity > 1:
            cart.quantity -= 1
        else:
            return jsonify({'error': 'Invalid action'}), 400
        
        try:
            db.session.commit()
            return jsonify({
                'success': True,
                'new_quantity': cart.quantity,
                'total_value': float(cart.quantity * cart.product.price)
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    @app.route('/admin/carts/<int:cart_id>/delete', methods=['DELETE'])
    def admin_delete_cart(cart_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Unauthorized access'}), 401
        
        cart = Cart.query.get_or_404(cart_id)
        
        try:
            db.session.delete(cart)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    @app.route('/admin/messages')
    def admin_messages():
        if session.get('role') != 'admin':
            flash('Access denied. Admin privileges required.', 'error')
            return redirect(url_for('index'))
        messages = Message.query.order_by(Message.timestamp.desc()).all()
        return render_template('admin_messages.html', messages=messages)

    @app.route('/api/messages/<int:message_id>')
    def get_message(message_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        message = Message.query.get_or_404(message_id)
        return jsonify({
            'success': True,
            'message': {
                'id': message.id,
                'order_id': message.order_id,
                'sender_name': message.sender.name,
                'receiver_name': message.receiver.name,
                'message': message.message,
                'timestamp': message.timestamp.isoformat(),
                'is_read': message.is_read
            }
        })

    @app.route('/admin/messages/delete/<int:message_id>', methods=['POST'])
    def admin_delete_message(message_id):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        message = Message.query.get_or_404(message_id)
        try:
            db.session.delete(message)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    # Add this route to your Flask application to provide detailed order information for invoices

    @app.route('/api/order-details/<int:order_id>')
    def get_order_details(order_id):
        if 'user_id' not in session:
            return jsonify({'error': 'Not logged in'}), 401
        
        # Get the order
        order = Order.query.get_or_404(order_id)
        
        # Get the product
        product = Product.query.get(order.product_id)
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Get the buyer
        buyer = User.query.get(order.user_id)
        if not buyer:
            return jsonify({'error': 'Buyer not found'}), 404
        
        # Calculate total price
        unit_price = float(product.price)
        total_price = unit_price * order.quantity
        
        # Prepare the response
        order_details = {
            'order_id': order.id,
            'order_date': order.order_date.strftime('%Y-%m-%d %H:%M:%S'),
            'product_id': product.id,
            'product_name': product.product_name,
            'product_description': product.product_description,
            'quantity': order.quantity,
            'unit_price': unit_price,
            'total_price': total_price,
            'payment_method': order.payment_method,
            'buyer_name': buyer.name,
            'buyer_email': buyer.email,
            'buyer_address': buyer.address,
            'buyer_phone': buyer.phone,
            'tax': round(total_price * 0.1, 2),  # Assuming 10% tax
            'shipping': 0,  # Assuming free shipping
            'grand_total': round(total_price * 1.1, 2)  # Total + tax
        }
        
        return jsonify({
            'success': True,
            'order': order_details
        })

    return app  # Ensure this return statement is correctly aligned inside `create_app()`
