// Function to check session status
async function checkSession() {
  try {
    const response = await fetch("/api/check-session", {
      credentials: "include",
    });
    const data = await response.json();
    if (!data.success) {
      window.location.href = "/login";
      return false;
    }
    return true;
  } catch (error) {
    console.error("Error checking session:", error);
    window.location.href = "/login";
    return false;
  }
}

document.addEventListener("DOMContentLoaded", async function () {
  // Check session first
  const isLoggedIn = await checkSession();
  if (!isLoggedIn) return;

  fetchProducts();
  document
    .getElementById("search-bar")
    .addEventListener("input", filterProducts);
});

let allProducts = []; // Store all products globally

function fetchProducts() {
  fetch("/api/products")
    .then((response) => response.json())
    .then((data) => {
      allProducts = data; // Store products
      displayProducts(allProducts);
      updateTotalProducts(allProducts.length); // Update total count
    })
    .catch((error) => console.error("Error fetching products:", error));
}

function displayProducts(products) {
  const productTable = document.getElementById("product-table-body");
  productTable.innerHTML = ""; // Clear previous data

  if (products.length === 0) {
    productTable.innerHTML = `<tr><td colspan="5" class="no-products">No products found.</td></tr>`;
    updateTotalProducts(0); // Update count if empty
    return;
  }

  products.forEach((product) => {
    const row = document.createElement("tr");

    row.innerHTML = `
            <td><img src="${
              product.main_image || "static/images/default-product.jpg"
            }" alt="${product.name}" class="product-table-image"></td>
            <td>${product.name}</td>
            <td>$${product.price}</td>
            <td class="${product.stock > 0 ? "in-stock" : "out-of-stock"}">${
      product.stock > 0 ? "In Stock" : "Out of Stock"
    }</td>
            <td class="product-actions">
                <i class="fas fa-edit edit-icon" data-id="${
                  product.id
                }" data-name="${product.name}" data-price="${
      product.price
    }" data-stock="${product.stock}" title="Edit"></i>
                <i class="fas fa-trash delete-icon" data-id="${
                  product.id
                }" title="Delete"></i>
            </td>
        `;

    productTable.appendChild(row);
  });

  // Add event listener for delete buttons
  document.querySelectorAll(".delete-icon").forEach((icon) => {
    icon.addEventListener("click", function () {
      const productId = this.getAttribute("data-id");
      if (confirm("Are you sure you want to delete this product?")) {
        deleteProduct(productId);
      }
    });
  });

  // Add event listener for edit buttons
  document.querySelectorAll(".edit-icon").forEach((icon) => {
    icon.addEventListener("click", function () {
      const productId = this.getAttribute("data-id");
      const productName = this.getAttribute("data-name");
      const productPrice = this.getAttribute("data-price");
      const productStock = this.getAttribute("data-stock");

      openEditModal(productId, productName, productPrice, productStock);
    });
  });

  updateTotalProducts(products.length); // Update count
}

function openEditModal(id, name, price, stock) {
  document.getElementById("edit-product-id").value = id;
  document.getElementById("edit-name").value = name;
  document.getElementById("edit-price").value = price;
  document.getElementById("edit-stock").value = stock;

  document.getElementById("edit-modal").style.display = "flex";
}

document.querySelector(".close-btn").addEventListener("click", function () {
  document.getElementById("edit-modal").style.display = "none";
});

document
  .getElementById("edit-form")
  .addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent page reload

    const id = document.getElementById("edit-product-id").value;
    const name = document.getElementById("edit-name").value;
    const price = document.getElementById("edit-price").value;
    const stock = document.getElementById("edit-stock").value;

    fetch(`/api/products/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: name,
        price: price,
        stock: stock,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Product updated:", data);
        location.reload(); // Refresh page to show updated data
      })
      .catch((error) => console.error("Error updating product:", error));
  });

function filterProducts() {
  const query = document.getElementById("search-bar").value.toLowerCase();
  const filteredProducts = allProducts.filter((product) =>
    product.name.toLowerCase().includes(query)
  );
  displayProducts(filteredProducts);
}

function updateTotalProducts(count) {
  const totalProductsElement = document.getElementById("total-products");
  totalProductsElement.textContent = `${count} Products`;
}

function deleteProduct(productId) {
  fetch(`/api/products/${productId}`, { method: "DELETE" })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to delete product");
      }
      return response.json();
    })
    .then(() => {
      // Remove deleted product from the array
      allProducts = allProducts.filter((product) => product.id !== productId);
      displayProducts(allProducts); // Refresh the table
      updateTotalProducts(allProducts.length); // Update total count
      location.reload();
    })
    .catch((error) => console.error("Error deleting product:", error));
}
