document.addEventListener("DOMContentLoaded", function () {
  // Notification dropdown toggle
  const notificationIcon = document.querySelector(".notification-icon");
  const notificationDropdown = document.querySelector(".notification-dropdown");

  notificationIcon.addEventListener("click", function (event) {
    event.stopPropagation();
    notificationDropdown.style.display =
      notificationDropdown.style.display === "block" ? "none" : "block";
  });

  // Profile dropdown toggle
  const profileTrigger = document.querySelector(".profile-trigger");
  const profileDropdown = document.querySelector(".profile-dropdown");

  profileTrigger.addEventListener("click", function (event) {
    event.stopPropagation();
    profileDropdown.style.display =
      profileDropdown.style.display === "block" ? "none" : "block";
  });

  // Close dropdowns when clicking outside
  document.addEventListener("click", function () {
    notificationDropdown.style.display = "none";
    profileDropdown.style.display = "none";
  });

  // Prevent dropdown close when clicking inside
  notificationDropdown.addEventListener("click", function (event) {
    event.stopPropagation();
  });

  profileDropdown.addEventListener("click", function (event) {
    event.stopPropagation();
  });

  // Responsive table handling
  const tableContainer = document.querySelector(".table-container");
  if (tableContainer) {
    const table = tableContainer.querySelector("table");
    const tableWidth = table.offsetWidth;
    const containerWidth = tableContainer.offsetWidth;

    if (tableWidth > containerWidth) {
      tableContainer.style.overflowX = "auto";
    }
  }

  // Action buttons functionality
  const actionButtons = document.querySelectorAll(".action-btn");

  actionButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const row = this.closest("tr");
      const orderId = row.cells[0].textContent;

      // You can replace this with actual functionality
      alert(`Update order ${orderId}`);
    });
  });

  // Add active class to current page in navbar
  const currentPage = window.location.pathname.split("/").pop();
  const navLinks = document.querySelectorAll(".nav-links a");

  navLinks.forEach((link) => {
    const linkPage = link.getAttribute("href");
    if (linkPage === currentPage) {
      link.classList.add("active");
    }
  });
});
