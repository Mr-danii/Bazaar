// Function to check session status
async function checkSession() {
  try {
    const response = await fetch("/api/check-session", {
      credentials: "include",
    });
    const data = await response.json();
    if (!data.success) {
      window.location.href = "/login";
      return false;
    }
    return true;
  } catch (error) {
    console.error("Error checking session:", error);
    window.location.href = "/login";
    return false;
  }
}

// Global variable to store all orders
let allOrders = [];

document.addEventListener("DOMContentLoaded", async () => {
  // Check session first
  const isLoggedIn = await checkSession();
  if (!isLoggedIn) return;

  // Create custom confirm modal
  createConfirmModal();

  // Fetch orders intended for the seller
  fetchOrders();

  // Function to fetch orders from the server
  function fetchOrders() {
    fetch("/get-orders-for-my-products")
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          allOrders = data.orders;
          console.log("Fetched orders for seller:", allOrders);

          // Get the active tab
          const activeTab = document
            .querySelector(".tab-btn.active")
            ?.getAttribute("data-tab");
          filterAndDisplayOrders(activeTab); // Display orders for the active tab
        } else {
          showNotification(
            "error",
            "Failed to fetch seller orders: " + (data.error || "Unknown error")
          );
        }
      })
      .catch((error) => {
        console.error("Error fetching seller orders:", error);
        showNotification("error", "Failed to load seller orders.");
      });
  }

  // Function to display orders in the list
  function displayOrders(orders) {
    const container = document.getElementById("sellerOrdersList");
    if (!container) {
      console.error("#sellerOrdersList element not found.");
      return;
    }
    container.innerHTML = ""; // Clear previous orders

    if (!orders || orders.length === 0) {
      container.innerHTML = "<p>No orders found.</p>";
      return;
    }

    orders.forEach((order) => {
      const card = document.createElement("div");
      card.className = "order-item"; // Keep the class for any existing CSS
      card.dataset.orderId = order.order_id; // Store order ID in the DOM element
      card.dataset.orderState = order.state ? order.state.toLowerCase() : ""; // Store order state

      // Add inline styles for enhanced appearance
      card.style.border = "1px solid #e0e0e0";
      card.style.borderRadius = "8px";
      card.style.padding = "16px";
      card.style.marginBottom = "20px";
      card.style.backgroundColor = "#fff";
      card.style.boxShadow = "0 2px 8px rgba(0,0,0,0.08)";
      card.style.transition =
        "transform 0.2s, box-shadow 0.2s, opacity 0.5s ease";

      card.addEventListener("mouseover", function () {
        this.style.transform = "translateY(-3px)";
        this.style.boxShadow = "0 4px 12px rgba(0,0,0,0.12)";
      });

      card.addEventListener("mouseout", function () {
        this.style.transform = "translateY(0)";
        this.style.boxShadow = "0 2px 8px rgba(0,0,0,0.08)";
      });

      const productImage =
        order.image_01 && order.image_01 !== "Unknown"
          ? `<img src="/${order.image_01}" alt="${
              order.product_name || "Product"
            }" style="width: 100%; height: 100%; object-fit: cover; display: block;">`
          : `<img src="/static/images/default-product.jpg" alt="Default image" style="width: 100%; height: 100%; object-fit: cover; display: block;">`;

      // Message Buyer Button Logic
      // Message Buyer Button Logic
      const messageButton = order.buyer_id
        ? `<button class="message-buyer-btn" 
           data-order-id="${order.order_id}" 
           data-buyer-id="${order.buyer_id}"
           style="background-color: #ff8c00; color: white; border: none; border-radius: 4px; padding: 6px 12px; margin-right: 5px; cursor: pointer; font-size: 14px; transition: background-color 0.2s, transform 0.1s;"
           onmouseover="this.style.backgroundColor='#e67e00'; this.style.transform='scale(1.03)'"
           onmouseout="this.style.backgroundColor='#ff8c00'; this.style.transform='scale(1)'">
       <i class="fas fa-comment"></i> Message Buyer
   </button>`
        : "";

      // Get the active tab to determine which buttons to show
      const activeTab = document
        .querySelector(".tab-btn.active")
        ?.getAttribute("data-tab");

      const currentState = order.state ? order.state.toLowerCase() : "";

      // Initialize buttons
      let stateButton = "";
      let cancelButton = "";

      // Show specific buttons based on tab and order state
      if (activeTab === "pending" && currentState === "pending") {
        // Show "Mark as Processing" button in pending tab
        stateButton = `<button class="process-order-btn" 
                    data-order-id="${order.order_id}"
                    style="background-color: #fbbc05; color: white; border: none; border-radius: 4px; padding: 6px 12px; margin-right: 5px; cursor: pointer; font-size: 14px; transition: background-color 0.2s, transform 0.1s;" 
                    onmouseover="this.style.backgroundColor='#e8ac04'; this.style.transform='scale(1.03)'" 
                    onmouseout="this.style.backgroundColor='#fbbc05'; this.style.transform='scale(1)'">
                    <i class="fas fa-sync-alt"></i> Mark as Processing
                </button>`;

        // Show cancel button for pending orders
        cancelButton = `<button class="cancel-order-btn" 
                    data-order-id="${order.order_id}"
                    style="background-color: #ea4335; color: white; border: none; border-radius: 4px; padding: 6px 12px; cursor: pointer; font-size: 14px; transition: background-color 0.2s, transform 0.1s;"
                    onmouseover="this.style.backgroundColor='#d73125'; this.style.transform='scale(1.03)'"
                    onmouseout="this.style.backgroundColor='#ea4335'; this.style.transform='scale(1)'">
                    <i class="fas fa-times-circle"></i> Cancel Order
                </button>`;
      } else if (activeTab === "processing" && currentState === "processing") {
        // Show "Mark as Shipping" button in processing tab
        stateButton = `<button class="ship-order-btn" 
                    data-order-id="${order.order_id}"
                    style="background-color: #4285f4; color: white; border: none; border-radius: 4px; padding: 6px 12px; margin-right: 5px; cursor: pointer; font-size: 14px; transition: background-color 0.2s, transform 0.1s;" 
                    onmouseover="this.style.backgroundColor='#3b78e7'; this.style.transform='scale(1.03)'" 
                    onmouseout="this.style.backgroundColor='#4285f4'; this.style.transform='scale(1)'">
                    <i class="fas fa-truck"></i> Mark as Shipping
                </button>
                <button class="print-invoice-btn" 
                    data-order-id="${order.order_id}"
                    data-order-date="${order.order_date || "N/A"}"
                    data-product-name="${order.product_name || "N/A"}"
                    data-quantity="${order.quantity || "1"}"
                    data-payment-method="${order.payment_method || "N/A"}"
                    data-buyer-name="${order.buyer_name || "N/A"}"
                    style="background-color: #673ab7; color: white; border: none; border-radius: 4px; padding: 6px 12px; margin-right: 5px; cursor: pointer; font-size: 14px; transition: background-color 0.2s, transform 0.1s;" 
                    onmouseover="this.style.backgroundColor='#5e35b1'; this.style.transform='scale(1.03)'" 
                    onmouseout="this.style.backgroundColor='#673ab7'; this.style.transform='scale(1)'">
                    <i class="fas fa-file-invoice"></i> Print Invoice
                </button>`;

        // Show cancel button for processing orders
        cancelButton = `<button class="cancel-order-btn" 
                    data-order-id="${order.order_id}"
                    style="background-color: #ea4335; color: white; border: none; border-radius: 4px; padding: 6px 12px; cursor: pointer; font-size: 14px; transition: background-color 0.2s, transform 0.1s;"
                    onmouseover="this.style.backgroundColor='#d73125'; this.style.transform='scale(1.03)'"
                    onmouseout="this.style.backgroundColor='#ea4335'; this.style.transform='scale(1)'">
                    <i class="fas fa-times-circle"></i> Cancel Order
                </button>`;
      } else if (activeTab === "shipping" && currentState === "shipping") {
        // Show "Mark as Delivered" button in shipping tab
        stateButton = `<button class="deliver-order-btn" 
                    data-order-id="${order.order_id}"
                    style="background-color: #34a853; color: white; border: none; border-radius: 4px; padding: 6px 12px; margin-right: 5px; cursor: pointer; font-size: 14px; transition: background-color 0.2s, transform 0.1s;" 
                    onmouseover="this.style.backgroundColor='#2d9249'; this.style.transform='scale(1.03)'" 
                    onmouseout="this.style.backgroundColor='#34a853'; this.style.transform='scale(1)'">
                    <i class="fas fa-check-circle"></i> Mark as Delivered
                </button>`;
      }
      // No action buttons for delivered or cancelled orders

      // Build the order card HTML
      card.innerHTML = `
                <div class="order-header" style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 15px;">
                    <div class="order-info" style="flex: 1;">
                        <h5 style="margin: 0; font-size: 18px; color: #333;">Order #${
                          order.order_id
                        }</h5>
                        <p class="order-date" style="margin: 5px 0 0; font-size: 14px; color: #666;">Date: ${
                          order.order_date || "N/A"
                        }</p>
                        <p style="margin: 5px 0 0; font-size: 14px; color: #666;">Buyer: ${
                          order.buyer_name || "N/A"
                        }</p>
                    </div>
                    <div class="order-actions" style="display: flex; flex-wrap: wrap; gap: 5px; justify-content: flex-end;">
                        ${messageButton}
                        ${stateButton}
                        ${cancelButton}
                    </div>
                </div>
                <div class="order-details" style="display: flex; gap: 15px; align-items: flex-start;">
                    <div class="product-image-container" style="flex-shrink: 0; width: 100px; height: 100px; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                        ${productImage}
                    </div>
                    <div class="product-info" style="flex: 1; color: #444;">
                        <p style="margin: 0 0 8px;"><strong>Product Name:</strong> ${
                          order.product_name || "N/A"
                        }</p>
                        <p style="margin: 0 0 8px;"><strong>Quantity:</strong> ${
                          order.quantity || "N/A"
                        }</p>
                        <p style="margin: 0 0 8px;"><strong>Payment Method:</strong> ${
                          order.payment_method || "N/A"
                        }</p>
                        <p style="margin: 0 0 8px;"><strong>Current State:</strong> 
                            <span class="order-state" style="display: inline-block; padding: 3px 8px; border-radius: 12px; font-size: 12px; font-weight: bold; 
                                ${
                                  currentState === "delivered"
                                    ? "background-color: #34a853; color: white;"
                                    : currentState === "shipping"
                                    ? "background-color: #4285f4; color: white;"
                                    : currentState === "processing"
                                    ? "background-color: #fbbc05; color: white;"
                                    : currentState === "cancelled"
                                    ? "background-color: #ea4335; color: white;"
                                    : "background-color: #f1f1f1; color: #333;"
                                }">
                                ${order.state || "N/A"}
                            </span>
                        </p>
                    </div>
                </div>
            `;

      container.appendChild(card);
    });

    // Attach event listeners after orders are added to the DOM
    attachButtonListeners(container);
  }

  // Create custom confirm modal
  function createConfirmModal() {
    // Check if modal already exists
    if (document.getElementById("customConfirmModal")) {
      return;
    }

    const modalHTML = `
      <div id="customConfirmModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center;">
        <div style="background-color: white; border-radius: 8px; width: 400px; max-width: 90%; box-shadow: 0 4px 15px rgba(0,0,0,0.2); overflow: hidden;">
          <div style="padding: 20px; border-bottom: 1px solid #eee;">
            <h3 id="confirmTitle" style="margin: 0; color: #333; font-size: 18px;">Confirm Action</h3>
          </div>
          <div style="padding: 20px;">
            <p id="confirmMessage" style="margin: 0 0 20px; color: #555; font-size: 16px;">Are you sure you want to proceed?</p>
          </div>
          <div style="padding: 15px; background-color: #f8f9fa; display: flex; justify-content: flex-end; gap: 10px;">
            <button id="confirmCancel" style="padding: 8px 15px; background-color: #f1f1f1; border: none; border-radius: 4px; color: #333; cursor: pointer;">Cancel</button>
            <button id="confirmOk" style="padding: 8px 15px; background-color: #4285f4; border: none; border-radius: 4px; color: white; cursor: pointer;">Confirm</button>
          </div>
        </div>
      </div>
    `;

    // Add modal to body
    const modalContainer = document.createElement("div");
    modalContainer.innerHTML = modalHTML;
    document.body.appendChild(modalContainer.firstElementChild);

    // Add event listeners
    document.getElementById("confirmCancel").addEventListener("click", () => {
      hideConfirmModal();
    });
  }

  // Show custom confirm modal
  function showConfirmModal(title, message, callback) {
    const modal = document.getElementById("customConfirmModal");
    const titleEl = document.getElementById("confirmTitle");
    const messageEl = document.getElementById("confirmMessage");
    const confirmBtn = document.getElementById("confirmOk");

    titleEl.textContent = title;
    messageEl.textContent = message;

    // Remove previous event listener
    const newConfirmBtn = confirmBtn.cloneNode(true);
    confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);

    // Add new event listener
    newConfirmBtn.addEventListener("click", () => {
      hideConfirmModal();
      callback();
    });

    modal.style.display = "flex";
  }

  // Hide custom confirm modal
  function hideConfirmModal() {
    const modal = document.getElementById("customConfirmModal");
    modal.style.display = "none";
  }

  // Function to show notification
  function showNotification(type, message) {
    const color = type === "success" ? "#34a853" : "#ea4335";
    const icon = type === "success" ? "check-circle" : "exclamation-circle";

    // Create notification element
    const notification = document.createElement("div");
    notification.innerHTML = `
      <div style="position: fixed; top: 20px; right: 20px; background-color: ${color}; color: white; padding: 15px; border-radius: 4px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); z-index: 1000; opacity: 0; transition: opacity 0.3s ease;">
        <p style="margin: 0;"><i class="fas fa-${icon}"></i> ${message}</p>
      </div>
    `;

    const notificationElement = notification.firstElementChild;
    document.body.appendChild(notificationElement);

    // Fade in
    setTimeout(() => {
      notificationElement.style.opacity = "1";
    }, 10);

    // Remove after delay
    setTimeout(() => {
      notificationElement.style.opacity = "0";
      setTimeout(() => {
        if (document.body.contains(notificationElement)) {
          document.body.removeChild(notificationElement);
        }
      }, 300);
    }, 3000);
  }

  // Attach listeners for message and update state buttons
  function attachButtonListeners(container) {
    container.addEventListener("click", (event) => {
      // Message Buyer Button Listener
      const messageBtn = event.target.closest(".message-buyer-btn");
      if (messageBtn) {
        const orderId = messageBtn.dataset.orderId;
        const buyerId = messageBtn.dataset.buyerId;
        console.log(
          `Message Buyer button clicked: Order ${orderId}, Buyer ${buyerId}`
        );
        // Call the globally available loadMessages function (from inline script in vieworders.html)
        if (typeof window.loadMessages === "function") {
          window.loadMessages(orderId, buyerId);
        } else {
          console.error("loadMessages function not found globally.");
        }
        return; // Stop further checks
      }

      // Process Order Button Listener (Pending -> Processing)
      const processBtn = event.target.closest(".process-order-btn");
      if (processBtn) {
        const orderId = processBtn.dataset.orderId;
        console.log(`Process order button clicked for Order ${orderId}`);

        showConfirmModal(
          "Mark as Processing",
          "Are you sure you want to mark this order as processing?",
          () => updateOrderState(orderId, processBtn, "processing")
        );
        return;
      }

      // Ship Order Button Listener (Processing -> Shipping)
      const shipBtn = event.target.closest(".ship-order-btn");
      if (shipBtn) {
        const orderId = shipBtn.dataset.orderId;
        console.log(`Ship order button clicked for Order ${orderId}`);

        showConfirmModal(
          "Mark as Shipping",
          "Are you sure you want to mark this order as shipping?",
          () => updateOrderState(orderId, shipBtn, "shipping")
        );
        return;
      }

      // Deliver Order Button Listener (Shipping -> Delivered)
      const deliverBtn = event.target.closest(".deliver-order-btn");
      if (deliverBtn) {
        const orderId = deliverBtn.dataset.orderId;
        console.log(`Deliver order button clicked for Order ${orderId}`);

        showConfirmModal(
          "Mark as Delivered",
          "Are you sure you want to mark this order as delivered?",
          () => updateOrderState(orderId, deliverBtn, "delivered")
        );
        return;
      }

      // Cancel Order Button Listener
      const cancelBtn = event.target.closest(".cancel-order-btn");
      if (cancelBtn) {
        const orderId = cancelBtn.dataset.orderId;
        console.log(`Cancel order button clicked for Order ${orderId}`);

        showConfirmModal(
          "Cancel Order",
          "Are you sure you want to cancel this order? This action cannot be undone.",
          () => cancelOrder(orderId, cancelBtn)
        );
        return;
      }

      // Print Invoice Button Listener
      const printInvoiceBtn = event.target.closest(".print-invoice-btn");
      if (printInvoiceBtn) {
        const orderId = printInvoiceBtn.dataset.orderId;
        console.log(`Print Invoice button clicked for Order ${orderId}`);
        generateInvoicePDF(printInvoiceBtn);
        return;
      }
    });
  }

  // Function to handle updating order state
  function updateOrderState(orderId, buttonElement, newState) {
    // Store original text and disable button
    const originalText = buttonElement.textContent;
    buttonElement.disabled = true;
    buttonElement.textContent = "Updating...";

    // Add timeout to the fetch request
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

    fetch(`/update-order-state/${orderId}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ new_state: newState }),
      signal: controller.signal,
    })
      .then((response) => {
        clearTimeout(timeoutId);
        if (!response.ok) {
          throw new Error(`Server responded with status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        if (data.success) {
          // Show success message
          showNotification(
            "success",
            data.message || `Order marked as ${newState} successfully!`
          );

          // Update the order in the global allOrders array
          for (let i = 0; i < allOrders.length; i++) {
            if (allOrders[i].order_id.toString() === orderId.toString()) {
              allOrders[i].state =
                newState.charAt(0).toUpperCase() + newState.slice(1);
              break;
            }
          }

          // Get the active tab
          const activeTab = document
            .querySelector(".tab-btn.active")
            ?.getAttribute("data-tab");

          // If we're in a tab that doesn't match the new state, remove the order card with animation
          if (activeTab !== newState) {
            const orderCard = buttonElement.closest(".order-item");
            if (orderCard) {
              // Fade out animation
              orderCard.style.opacity = "0";

              setTimeout(() => {
                if (orderCard.parentNode) {
                  orderCard.parentNode.removeChild(orderCard);
                }

                // Check if there are no more orders
                const container = document.getElementById("sellerOrdersList");
                if (container && container.children.length === 0) {
                  container.innerHTML = "<p>No orders found.</p>";
                }
              }, 500);
            }

            // Switch to the new state tab after a short delay
            setTimeout(() => {
              // Find the tab button for the new state and click it
              const newStateTabBtn = document.querySelector(
                `.tab-btn[data-tab="${newState}"]`
              );
              if (newStateTabBtn) {
                newStateTabBtn.click();
              }
            }, 1000);
          } else {
            // If we're already in the correct tab, just refresh the view
            filterAndDisplayOrders(activeTab);
          }
        } else {
          // Show error message
          showNotification("error", data.error || "Error updating order state");

          // Reset button
          buttonElement.disabled = false;
          buttonElement.textContent = originalText;
        }
      })
      .catch((error) => {
        clearTimeout(timeoutId);
        console.error("Error updating order state:", error);

        // Show appropriate error message based on error type
        if (error.name === "AbortError") {
          showNotification("error", "Request timed out. Please try again.");
        } else {
          showNotification(
            "error",
            "Network error. Please check your connection and try again."
          );
        }

        // Reset button
        buttonElement.disabled = false;
        buttonElement.textContent = originalText;
      });
  }

  // Function to handle cancelling an order
  function cancelOrder(orderId, buttonElement) {
    // Disable button and show loading state
    buttonElement.disabled = true;
    const originalHTML = buttonElement.innerHTML;
    buttonElement.innerHTML =
      '<i class="fas fa-spinner fa-spin"></i> Cancelling...';

    // Add timeout to the fetch request
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

    fetch(`/cancel-order/${orderId}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      signal: controller.signal,
    })
      .then((response) => {
        clearTimeout(timeoutId);
        if (!response.ok) {
          throw new Error(`Server responded with status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        if (data.success) {
          // Show success message
          showNotification(
            "success",
            data.message || "Order cancelled successfully!"
          );

          // Update the order in the global allOrders array
          for (let i = 0; i < allOrders.length; i++) {
            if (allOrders[i].order_id.toString() === orderId.toString()) {
              allOrders[i].state = "Cancelled";
              break;
            }
          }

          // Get the active tab
          const activeTab = document
            .querySelector(".tab-btn.active")
            ?.getAttribute("data-tab");

          // If we're not in the cancelled tab, remove the order card with animation
          if (activeTab !== "cancelled") {
            const orderCard = buttonElement.closest(".order-item");
            if (orderCard) {
              // Fade out animation
              orderCard.style.opacity = "0";

              setTimeout(() => {
                if (orderCard.parentNode) {
                  orderCard.parentNode.removeChild(orderCard);
                }

                // Check if there are no more orders
                const container = document.getElementById("sellerOrdersList");
                if (container && container.children.length === 0) {
                  container.innerHTML = "<p>No orders found.</p>";
                }
              }, 500);
            }

            // Switch to the cancelled tab after a short delay
            setTimeout(() => {
              // Find the cancelled tab button and click it
              const cancelledTabBtn = document.querySelector(
                '.tab-btn[data-tab="cancelled"]'
              );
              if (cancelledTabBtn) {
                cancelledTabBtn.click();
              }
            }, 1000);
          } else {
            // If we're already in the cancelled tab, just refresh the view
            filterAndDisplayOrders(activeTab);
          }
        } else {
          // Show error message
          showNotification("error", data.error || "Error cancelling order");

          // Reset button
          buttonElement.disabled = false;
          buttonElement.innerHTML = originalHTML;
        }
      })
      .catch((error) => {
        clearTimeout(timeoutId);
        console.error("Error cancelling order:", error);

        // Show appropriate error message based on error type
        if (error.name === "AbortError") {
          showNotification("error", "Request timed out. Please try again.");
        } else {
          showNotification(
            "error",
            "Network error. Please check your connection and try again."
          );
        }

        // Reset button
        buttonElement.disabled = false;
        buttonElement.innerHTML = originalHTML;
      });
  }

  // --- Tab Filtering Logic ---
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document
        .querySelectorAll(".tab-btn")
        .forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      const tab = btn.getAttribute("data-tab");
      filterAndDisplayOrders(tab);
    });
  });

  // --- Search Functionality ---
  const searchInput = document.querySelector(".order-search input");
  const searchButton = document.querySelector(".order-search button");

  function performSearch() {
    const query = searchInput.value.toLowerCase().trim();
    if (!query) {
      // Get the active tab
      const activeTab = document
        .querySelector(".tab-btn.active")
        ?.getAttribute("data-tab");
      filterAndDisplayOrders(activeTab);
      return;
    }

    // First filter by active tab
    const activeTab = document
      .querySelector(".tab-btn.active")
      ?.getAttribute("data-tab");
    let filteredOrders = allOrders;

    if (activeTab) {
      filteredOrders = filteredOrders.filter(
        (o) => o.state && o.state.toLowerCase() === activeTab
      );
    }

    // Then apply search filter
    const results = filteredOrders.filter((o) => {
      const orderIdMatch = o.order_id.toString().includes(query);
      const productNameMatch = (o.product_name || "")
        .toLowerCase()
        .includes(query);
      const buyerNameMatch = (o.buyer_name || "").toLowerCase().includes(query);
      return orderIdMatch || productNameMatch || buyerNameMatch;
    });

    displayOrders(results);
  }

  searchButton.addEventListener("click", performSearch);
  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      performSearch();
    }
  });

  // --- Filter by Date ---
  document
    .querySelector(".order-filter select")
    .addEventListener("change", (e) => {
      const value = e.target.value;
      const now = new Date();

      // First filter by active tab
      const activeTab = document
        .querySelector(".tab-btn.active")
        ?.getAttribute("data-tab");
      let filteredOrders = allOrders;

      if (activeTab) {
        filteredOrders = filteredOrders.filter(
          (o) => o.state && o.state.toLowerCase() === activeTab
        );
      }

      // Then apply date filter
      if (!value) {
        // No date filter, just use tab filter
      } else if (value === "last-30-days") {
        const cutoff = new Date();
        cutoff.setDate(now.getDate() - 30);
        filteredOrders = filteredOrders.filter(
          (o) => new Date(o.order_date) >= cutoff
        );
      } else if (value === "last-6-months") {
        const cutoff = new Date();
        cutoff.setMonth(now.getMonth() - 6);
        filteredOrders = filteredOrders.filter(
          (o) => new Date(o.order_date) >= cutoff
        );
      } else if (value === "2024" || value === "2023" || value === "2022") {
        filteredOrders = filteredOrders.filter(
          (o) => new Date(o.order_date).getFullYear().toString() === value
        );
      }

      displayOrders(filteredOrders);
      console.log("Date filtration applied:", value);
    });

  // Combined filter and display function
  function filterAndDisplayOrders(activeTab = null) {
    if (!activeTab) {
      const activeBtn = document.querySelector(".tab-btn.active");
      if (activeBtn) {
        activeTab = activeBtn.getAttribute("data-tab");
      }
    }

    let filteredOrders = allOrders;

    // Apply tab filter - only show orders that match the active tab
    if (activeTab) {
      filteredOrders = filteredOrders.filter(
        (o) => o.state && o.state.toLowerCase() === activeTab
      );
    }

    displayOrders(filteredOrders);
  }

  // Function to switch to a specific tab
  function switchToTab(tabName) {
    const tabBtn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
    if (tabBtn) {
      document
        .querySelectorAll(".tab-btn")
        .forEach((b) => b.classList.remove("active"));
      tabBtn.classList.add("active");
      filterAndDisplayOrders(tabName);
    }
  }

  // Update badge count for cancelled orders
  function updateCancelledCount() {
    // Count cancelled orders
    const cancelledCount = allOrders.filter(
      (order) => order.state && order.state.toLowerCase() === "cancelled"
    ).length;

    // Find the cancelled tab button
    const cancelledTab = document.querySelector(
      '.tab-btn[data-tab="cancelled"]'
    );

    if (cancelledTab) {
      // If there's a badge already, update it, otherwise create one
      let badge = cancelledTab.querySelector(".badge");
      if (!badge && cancelledCount > 0) {
        badge = document.createElement("span");
        badge.className = "badge";
        badge.style.position = "absolute";
        badge.style.top = "-8px";
        badge.style.right = "-8px";
        badge.style.backgroundColor = "#ea4335";
        badge.style.color = "white";
        badge.style.borderRadius = "50%";
        badge.style.width = "20px";
        badge.style.height = "20px";
        badge.style.display = "flex";
        badge.style.alignItems = "center";
        badge.style.justifyContent = "center";
        badge.style.fontSize = "12px";
        badge.style.fontWeight = "bold";

        // Make sure the tab button has position relative for absolute positioning of badge
        cancelledTab.style.position = "relative";
        cancelledTab.appendChild(badge);
      }

      if (badge) {
        if (cancelledCount > 0) {
          badge.textContent = cancelledCount > 99 ? "99+" : cancelledCount;
          badge.style.display = "flex";
        } else {
          badge.style.display = "none";
        }
      }
    }
  }

  // Call updateCancelledCount when the page loads
  updateCancelledCount();

  // Ensure loadMessages is available globally
  window.loadMessages =
    window.loadMessages ||
    ((orderId, buyerId) => {
      console.log(
        `Placeholder: loadMessages called for order ${orderId} and buyer ${buyerId}`
      );
      // This is just a placeholder - the actual function is defined in the HTML file
    });

  // Function to generate and download invoice PDF
  function generateInvoicePDF(buttonElement) {
    // Get order data from button data attributes
    const orderId = buttonElement.dataset.orderId;
    const orderDate = buttonElement.dataset.orderDate;
    const productName = buttonElement.dataset.productName;
    const quantity = buttonElement.dataset.quantity;
    const paymentMethod = buttonElement.dataset.paymentMethod;
    const buyerName = buttonElement.dataset.buyerName;

    // Fetch additional order details from server
    fetch(`/api/order-details/${orderId}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          createPDF(
            data.order,
            orderId,
            orderDate,
            productName,
            quantity,
            paymentMethod,
            buyerName
          );
        } else {
          // If API fails, create PDF with available data
          createPDF(
            null,
            orderId,
            orderDate,
            productName,
            quantity,
            paymentMethod,
            buyerName
          );
        }
      })
      .catch((error) => {
        console.error("Error fetching order details:", error);
        // Create PDF with available data if fetch fails
        createPDF(
          null,
          orderId,
          orderDate,
          productName,
          quantity,
          paymentMethod,
          buyerName
        );
      });
  }

  function createPDF(
    orderData,
    orderId,
    orderDate,
    productName,
    quantity,
    paymentMethod,
    buyerName
  ) {
    // Initialize jsPDF
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Set document properties
    doc.setProperties({
      title: `Invoice_Order_${orderId}`,
      subject: "Order Invoice",
      author: "Bazaar E-commerce",
      keywords: "invoice, order, e-commerce",
      creator: "Bazaar Invoice System",
    });

    // Add company logo/header
    doc.setFontSize(20);
    doc.setTextColor(255, 165, 0); // orange
    doc.text("BAZAAR", 105, 20, { align: "center" });

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text("E-commerce Marketplace", 105, 25, { align: "center" });

    // Add invoice title
    doc.setFontSize(18);
    doc.setTextColor(0, 0, 0);
    doc.text("INVOICE", 105, 40, { align: "center" });

    // Add horizontal line
    doc.setDrawColor(220, 220, 220);
    doc.line(20, 45, 190, 45);

    // Add invoice details
    doc.setFontSize(10);
    doc.setTextColor(80, 80, 80);

    // Left side - Invoice info
    doc.text("Invoice Number:", 20, 55);
    doc.text(`INV-${orderId}`, 70, 55);

    doc.text("Order Date:", 20, 60);
    doc.text(orderDate, 70, 60);

    doc.text("Order ID:", 20, 65);
    doc.text(`#${orderId}`, 70, 65);

    doc.text("Payment Method:", 20, 70);
    doc.text(paymentMethod, 70, 70);

    // Right side - Customer info
    doc.text("Customer:", 130, 55);
    doc.text(buyerName, 170, 55);

    // Add address if available
    if (orderData && orderData.buyer_address) {
      const addressLines = orderData.buyer_address.split(",");
      let yPos = 60;
      addressLines.forEach((line) => {
        doc.text(line.trim(), 170, yPos);
        yPos += 5;
      });
    }

    // Add horizontal line
    doc.setDrawColor(220, 220, 220);
    doc.line(20, 80, 190, 80);

    // Add order items table
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text("Order Items", 20, 90);

    // Create table
    const tableColumn = ["Product", "Quantity", "Unit Price", "Total"];
    const tableRows = [];

    // Get price from orderData if available, otherwise estimate
    const unitPrice =
      orderData && orderData.unit_price ? orderData.unit_price : 0;
    const totalPrice = unitPrice * Number.parseInt(quantity);

    // Add product row
    tableRows.push([
      productName,
      quantity,
      orderData ? `$${unitPrice.toFixed(2)}` : "N/A",
      orderData ? `$${totalPrice.toFixed(2)}` : "N/A",
    ]);

    // Add table to document
    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 95,
      theme: "grid",
      styles: {
        fontSize: 10,
        cellPadding: 6,
        lineColor: [220, 220, 220],
      },
      headStyles: {
        fillColor: [255, 165, 0],
        textColor: [0, 0, 0],
        fontStyle: "bold",
      },
      alternateRowStyles: {
        fillColor: [240, 240, 240],
      },
    });

    // Add total section
    const finalY = doc.lastAutoTable.finalY + 10;

    doc.setFontSize(10);
    doc.text("Subtotal:", 140, finalY);
    doc.text(orderData ? `$${totalPrice.toFixed(2)}` : "N/A", 180, finalY, {
      align: "right",
    });

    doc.text("Tax:", 140, finalY + 5);
    const tax = orderData && orderData.tax ? orderData.tax : totalPrice * 0.1;
    doc.text(orderData ? `$${tax.toFixed(2)}` : "N/A", 180, finalY + 5, {
      align: "right",
    });

    doc.setFontSize(12);
    doc.setFont(undefined, "bold");
    doc.text("Total:", 140, finalY + 15);
    const grandTotal = totalPrice + tax;
    doc.text(
      orderData ? `$${grandTotal.toFixed(2)}` : "N/A",
      180,
      finalY + 15,
      { align: "right" }
    );

    // Add footer
    doc.setFontSize(10);
    doc.setFont(undefined, "normal");
    doc.setTextColor(100, 100, 100);
    doc.text("Thank you for your business!", 105, finalY + 30, {
      align: "center",
    });

    // Add horizontal line
    doc.setDrawColor(220, 220, 220);
    doc.line(20, finalY + 40, 190, finalY + 40);

    // Add company info in footer
    doc.setFontSize(8);
    doc.text(
      "Bazaar E-commerce • Gulberg , Lahore • www.bazaar.com• ",
      105,
      finalY + 45,
      { align: "center" }
    );

    // Save the PDF
    doc.save(`Invoice_Order_${orderId}.pdf`);

    // Show success notification
    showNotification("success", "Invoice generated successfully!");
  }
});
