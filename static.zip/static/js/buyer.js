document.addEventListener("DOMContentLoaded", () => {
  // Mobile dropdown handling
  function setupMobileDropdowns() {
    // Get all dropdown elements
    const currencySelector = document.querySelector(".currency-selector")
    const accountItem = document.querySelector(".account-item")
    const currencyDropdown = document.querySelector(".currency-dropdown")
    const accountDropdown = document.querySelector(".account-dropdown")
    const navbar = document.getElementById("navbar")
    const headerNav = document.querySelector(".header-nav")

    // Function to close all dropdowns
    function closeAllDropdowns() {
      document.querySelectorAll(".currency-dropdown, .account-dropdown").forEach((dropdown) => {
        dropdown.style.display = "none"
      })

      // Remove active class from selectors
      document.querySelectorAll(".currency-selector, .account-item").forEach((selector) => {
        selector.classList.remove("active")
      })
    }

    // Handle currency selector click
    if (currencySelector) {
      currencySelector.addEventListener("click", function (e) {
        e.preventDefault()
        e.stopPropagation()

        // Get the dropdown within this selector
        const dropdown = this.querySelector(".currency-dropdown")
        if (dropdown) {
          // Toggle display
          if (dropdown.style.display === "block") {
            dropdown.style.display = "none"
            this.classList.remove("active")
          } else {
            // Close all other dropdowns first
            closeAllDropdowns()

            // Add active class to selector
            this.classList.add("active")

            // Show dropdown
            dropdown.style.display = "block"

            // For mobile: ensure dropdown is inside navbar
            if (window.innerWidth <= 768) {
              // Make sure header nav is open
              if (headerNav) {
                headerNav.classList.add("open")
              }

              // Position dropdown inside navbar
              dropdown.style.position = "relative"
              dropdown.style.top = "0"
              dropdown.style.left = "0"
              dropdown.style.width = "100%"
            } else {
              // Position the dropdown correctly relative to the navbar
              positionDropdown(dropdown, this)
            }
          }
        }
      })
    }

    // Handle account item click
    if (accountItem) {
      accountItem.addEventListener("click", function (e) {
        e.preventDefault()
        e.stopPropagation()

        // Get the dropdown within this selector
        const dropdown = this.querySelector(".account-dropdown")
        if (dropdown) {
          // Toggle display
          if (dropdown.style.display === "block") {
            dropdown.style.display = "none"
            this.classList.remove("active")
          } else {
            // Close all other dropdowns first
            closeAllDropdowns()

            // Add active class to selector
            this.classList.add("active")

            // Show dropdown
            dropdown.style.display = "block"

            // For mobile: ensure dropdown is inside navbar
            if (window.innerWidth <= 768) {
              // Make sure header nav is open
              if (headerNav) {
                headerNav.classList.add("open")
              }

              // Position dropdown inside navbar
              dropdown.style.position = "relative"
              dropdown.style.top = "0"
              dropdown.style.left = "0"
              dropdown.style.width = "100%"
            } else {
              // Position the dropdown correctly relative to the navbar
              positionDropdown(dropdown, this)
            }
          }
        }
      })
    }

    // Function to position dropdown correctly
    function positionDropdown(dropdown, parent) {
      // Get parent position
      const parentRect = parent.getBoundingClientRect()

      // Check if we're on mobile
      if (window.innerWidth <= 768) {
        // For mobile, make dropdown part of the flow
        dropdown.style.position = "relative"
        dropdown.style.top = "0"
        dropdown.style.left = "0"
        dropdown.style.width = "100%"
      } else {
        // For desktop, position absolutely
        dropdown.style.position = "absolute"
        dropdown.style.top = "100%"
        dropdown.style.left = "auto"
        dropdown.style.right = "0"

        // Make sure dropdown stays within viewport
        const dropdownRect = dropdown.getBoundingClientRect()
        const viewportWidth = window.innerWidth

        if (dropdownRect.right > viewportWidth) {
          // If dropdown extends beyond right edge, align it to the right
          dropdown.style.right = "0"
          dropdown.style.left = "auto"
        }
      }
    }

    // Close dropdowns when clicking elsewhere
    document.addEventListener("click", () => {
      closeAllDropdowns()
    })

    // Prevent dropdown clicks from closing the dropdown
    document.querySelectorAll(".currency-dropdown, .account-dropdown").forEach((dropdown) => {
      dropdown.addEventListener("click", (e) => {
        e.stopPropagation()
      })
    })
  }

  // Call this function after the page loads
  window.addEventListener("load", setupMobileDropdowns)
  // Also call it on resize to handle orientation changes
  window.addEventListener("resize", setupMobileDropdowns)

  let cart = []
  let allProducts = []
  let categories = []

  // Define currency variables - Make them globally accessible
  window.currentCurrency = "USD"
  window.currentSymbol = "$"

  // Initialize the page
  initializePage()

  // Currency conversion functionality
  const exchangeRates = {
    USD: 1,
    EUR: 0.92,
    PKR: 278.5,
    SAR: 3.75,
  }

  // Make exchange rates globally available
  window.exchangeRates = exchangeRates

  const currencySymbols = {
    USD: "$",
    EUR: "€",
    PKR: "₨",
    SAR: "﷼",
  }

  // Make currency symbols globally available
  window.currencySymbols = currencySymbols

  function convertPrice(price, fromCurrency = "USD", toCurrency = window.currentCurrency) {
    if (!price || isNaN(price)) return "0.00"
    const priceInUSD = Number.parseFloat(price) / exchangeRates[fromCurrency]
    return (priceInUSD * exchangeRates[toCurrency]).toFixed(2)
  }

  // Make convert price function globally available
  window.convertPrice = convertPrice

  function updateProductPrices() {
    const productCards = document.querySelectorAll(".product-card")
    productCards.forEach((card) => {
      const priceElement = card.querySelector(".product-price, .current-price")
      if (priceElement) {
        // Get the original price data attribute, or extract from text if not available
        let originalPrice
        if (priceElement.hasAttribute("data-original-price")) {
          originalPrice = priceElement.getAttribute("data-original-price")
        } else {
          // Extract the original price (remove any currency symbols)
          originalPrice = priceElement.textContent.replace(/[^0-9.]/g, "")
          // Store the original price as a data attribute for future conversions
          priceElement.setAttribute("data-original-price", originalPrice)
        }

        // Update with new currency and converted price
        priceElement.textContent = `${window.currentSymbol}${convertPrice(originalPrice)}`
      }
    })
  }

  // Sticky navbar with hide-on-scroll functionality
  let lastScrollTop = 0
  window.addEventListener("scroll", () => {
    const currentScroll = window.pageYOffset || document.documentElement.scrollTop
    const navbar = document.getElementById("navbar")

    if (currentScroll > lastScrollTop) {
      // Scrolling down
      navbar.classList.add("navbar-hidden")
    } else {
      // Scrolling up
      navbar.classList.remove("navbar-hidden")
    }
    lastScrollTop = currentScroll <= 0 ? 0 : currentScroll
  })

  // Slideshow functionality
  initializeSlideshow()

  // Category carousel navigation
  const categoryCarousel = document.querySelector(".category-scroll")
  const prevCategoryBtn = document.querySelector(".category-carousel .prev-btn")
  const nextCategoryBtn = document.querySelector(".category-carousel .next-btn")

  if (categoryCarousel && prevCategoryBtn && nextCategoryBtn) {
    const scrollAmount = 200 // Width of one category card + gap

    prevCategoryBtn.addEventListener("click", () => {
      categoryCarousel.scrollBy({
        left: -scrollAmount,
        behavior: "smooth",
      })
    })

    nextCategoryBtn.addEventListener("click", () => {
      categoryCarousel.scrollBy({
        left: scrollAmount,
        behavior: "smooth",
      })
    })
  }

  // Search functionality
  const searchInput = document.getElementById("search-input")
  const searchBtn = document.getElementById("search-btn")

  // Check if category select exists, if not, create a variable with default value
  const categorySelect = document.getElementById("category-select") || {
    value: "all",
  }

  if (searchBtn && searchInput) {
    searchBtn.addEventListener("click", () => {
      const query = searchInput.value.trim().toLowerCase()
      const category = categorySelect.value

      if (query) {
        searchProducts(query, category)

        // Scroll to search results section
        const categoryProductsSection = document.getElementById("category-products-section")
        if (categoryProductsSection) {
          categoryProductsSection.scrollIntoView({ behavior: "smooth" })
        }
      }
    })

    searchInput.addEventListener("keyup", (e) => {
      if (e.key === "Enter") {
        searchBtn.click()
      }
    })
  }

  // Sort products
  const sortSelect = document.getElementById("sort-select")
  if (sortSelect) {
    sortSelect.addEventListener("change", () => {
      const selectedCategory = document.getElementById("selected-category-title").textContent
      const filteredProducts =
        selectedCategory === "All Products"
          ? allProducts
          : allProducts.filter((p) => normalizeCategory(p.category) === normalizeCategory(selectedCategory))

      sortProducts(filteredProducts, sortSelect.value)
    })
  }

  // Setup currency selector - FIXED
  function setupCurrencySelector() {
    const currencyItems = document.querySelectorAll(".currency-dropdown a")
    const currentCurrencyElement = document.getElementById("current-currency")

    currencyItems.forEach((item) => {
      item.addEventListener("click", function (e) {
        e.preventDefault()

        // Get currency data
        const newCurrency = this.getAttribute("data-currency")
        const newSymbol = this.getAttribute("data-symbol")

        // Update current currency
        window.currentCurrency = newCurrency
        window.currentSymbol = newSymbol

        // Update display
        if (currentCurrencyElement) {
          currentCurrencyElement.textContent = newCurrency
        }

        // Update currency icon
        updateCurrencyIcon(newCurrency)

        // Update all prices
        updateAllPrices()

        // Close dropdown on mobile
        const dropdown = document.querySelector(".currency-dropdown")
        if (dropdown) {
          dropdown.classList.remove("active")
        }
      })
    })
  }

  // Update currency icon
  function updateCurrencyIcon(currency) {
    const iconElement = document.querySelector(".currency-selector a i:first-child")
    if (!iconElement) return

    // Remove all existing classes
    iconElement.className = ""

    // Add appropriate icon class
    switch (currency) {
      case "USD":
        iconElement.className = "fas fa-dollar-sign"
        break
      case "EUR":
        iconElement.className = "fas fa-euro-sign"
        break
      case "SAR":
        iconElement.className = "fas fa-money-bill-wave" // Using money bill for SAR
        break
      case "PKR":
        iconElement.className = "fas fa-rupee-sign" // Using rupee sign as closest to PKR
        break
      default:
        iconElement.className = "fas fa-dollar-sign"
    }
  }

  // Initialize currency selector
  setupCurrencySelector()

  // Functions
  function initializePage() {
    // Fetch popular products for slideshow
    fetchPopularProducts()

    // Fetch categories
    fetchCategories()

    // Fetch products
    fetchProducts()

    // Load cart from localStorage
    loadCart()
  }

  function fetchPopularProducts() {
    // In a real app, this would be an API call to get most viewed/purchased products
    fetch("/api/popular-products")
      .then((response) => {
        // If the API endpoint doesn't exist in your demo, handle the error
        if (!response.ok) {
          return Promise.resolve({
            success: true,
            popular_products: [],
          })
        }
        return response.json()
      })
      .then((data) => {
        if (data.success && data.popular_products && data.popular_products.length > 0) {
          updateSlideshow(data.popular_products)
        }
      })
      .catch((error) => {
        console.error("Error fetching popular products:", error)
      })
  }

  function updateSlideshow(popularProducts) {
    const slides = document.querySelectorAll(".slide")

    // Update each slide with popular product data
    popularProducts.forEach((product, index) => {
      if (index < slides.length) {
        const slide = slides[index]
        slide.setAttribute("data-category", product.category)
        slide.setAttribute("data-product-id", product.id)

        // Update image if available
        const img = slide.querySelector("img")
        if (img && product.main_image) {
          img.src = product.main_image
          img.alt = product.product_name
        }

        // Update title
        const title = slide.querySelector(".slide-title h2")
        if (title) {
          title.textContent = product.product_name
        }
      }
    })
  }

  function initializeSlideshow() {
    const slides = document.querySelectorAll(".slide")
    const dots = document.querySelectorAll(".dot")
    const prevBtn = document.querySelector(".prev-slide")
    const nextBtn = document.querySelector(".next-slide")
    let currentSlide = 0
    let slideInterval

    // Initialize slideshow
    function startSlideshow() {
      slideInterval = setInterval(nextSlide, 5000)
    }

    // Show specific slide
    function showSlide(index) {
      // Hide all slides
      slides.forEach((slide) => {
        slide.classList.remove("active")
      })

      // Remove active class from all dots
      dots.forEach((dot) => {
        dot.classList.remove("active")
      })

      // Show the selected slide and activate corresponding dot
      slides[index].classList.add("active")
      dots[index].classList.add("active")

      // Update current slide index
      currentSlide = index
    }

    // Next slide function
    function nextSlide() {
      let next = currentSlide + 1
      if (next >= slides.length) {
        next = 0
      }
      showSlide(next)
    }

    // Previous slide function
    function prevSlide() {
      let prev = currentSlide - 1
      if (prev < 0) {
        prev = slides.length - 1
      }
      showSlide(prev)
    }

    // Event listeners for controls
    if (prevBtn && nextBtn) {
      prevBtn.addEventListener("click", (e) => {
        e.stopPropagation() // Prevent click from bubbling to slide
        clearInterval(slideInterval)
        prevSlide()
        startSlideshow()
      })

      nextBtn.addEventListener("click", (e) => {
        e.stopPropagation() // Prevent click from bubbling to slide
        clearInterval(slideInterval)
        nextSlide()
        startSlideshow()
      })
    }

    // Dot navigation
    if (dots.length > 0) {
      dots.forEach((dot, index) => {
        dot.addEventListener("click", (e) => {
          e.stopPropagation() // Prevent click from bubbling to slide
          clearInterval(slideInterval)
          showSlide(index)
          startSlideshow()
        })
      })
    }

    // Make slides clickable to show related products
    slides.forEach((slide) => {
      slide.addEventListener("click", () => {
        const category = slide.getAttribute("data-category")
        const productId = slide.getAttribute("data-product-id")

        if (category) {
          // Create the selected-category-title element if it doesn't exist
          let categoryTitle = document.getElementById("selected-category-title")
          if (!categoryTitle) {
            categoryTitle = document.createElement("h2")
            categoryTitle.id = "selected-category-title"
            document.body.appendChild(categoryTitle) // Temporary append
          }

          categoryTitle.textContent = category

          // Use case-insensitive comparison for category filtering
          let filteredProducts = allProducts.filter(
            (p) => normalizeCategory(p.category) === normalizeCategory(category),
          )

          console.log(`Slide clicked: ${category}, Found products: ${filteredProducts.length}`)

          // If no products found, try to match with similar categories
          if (filteredProducts.length === 0) {
            filteredProducts = findProductsBySimilarCategory(category)
            console.log(`Using similar categories, found: ${filteredProducts.length}`)
          }

          // If we have a specific product ID, put that product first in the list
          if (productId) {
            const productIdNum = Number.parseInt(productId)
            filteredProducts = filteredProducts.sort((a, b) => {
              if (a.id === productIdNum) return -1
              if (b.id === productIdNum) return 1
              return 0
            })
          }

          renderCategoryProducts(filteredProducts)

          // Scroll to products section
          const categoryProductsSection = document.getElementById("category-products-section")
          if (categoryProductsSection) {
            categoryProductsSection.scrollIntoView({ behavior: "smooth" })
          }
        }
      })
    })

    // Start the slideshow if slides exist
    if (slides.length > 0) {
      startSlideshow()
    }
  }

  function fetchCategories() {
    // Try to fetch categories from API
    fetch("/api/categories")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok")
        }
        return response.json()
      })
      .then((data) => {
        if (data.success && data.categories) {
          categories = data.categories
        } else {
          // Fallback to hardcoded categories
          categories = [
            {
              id: 1,
              name: "Electronics",
              image: "/static/images/electronics.jpg",
            },
            { id: 2, name: "Fashion", image: "/static/images/fashion.webp" },
            { id: 3, name: "Home", image: "/static/images/home.jpg" },
            { id: 4, name: "Toys", image: "/static/images/toys.jpg" },
            { id: 5, name: "Beauty", image: "/static/images/beauty.jpg" },
            { id: 6, name: "Kitchen", image: "/static/images/kitchen.jpeg" },
            { id: 7, name: "Sports", image: "/static/images/sports.jpeg" },
            { id: 8, name: "Books", image: "/static/images/books.webp" },
            { id: 9, name: "Gaming", image: "/static/images/gaming.jpg" },
          ]
        }
        renderCategories()
      })
      .catch((error) => {
        console.error("Error fetching categories:", error)
        // Fallback to hardcoded categories
        categories = [
          {
            id: 1,
            name: "Electronics",
            image: "/static/images/electronics.jpg",
          },
          { id: 2, name: "Fashion", image: "/static/images/fashion.webp" },
          { id: 3, name: "Home", image: "/static/images/home.jpg" },
          { id: 4, name: "Toys", image: "/static/images/toys.jpg" },
          { id: 5, name: "Beauty", image: "/static/images/beauty.jpg" },
          {
            id: 6,
            name: "Kitchen",
            image: "/static/images/kitchen-products.jpg",
          },
          { id: 7, name: "Sports", image: "/static/images/sports.jpeg" },
          { id: 8, name: "Books", image: "/static/images/books.webp" },
          { id: 9, name: "Gaming", image: "/static/images/gaming.jpg" },
        ]
        renderCategories()
      })
  }

  function renderCategories() {
    const categoryScroll = document.getElementById("category-scroll")
    if (!categoryScroll) return

    categoryScroll.innerHTML = ""

    categories.forEach((category) => {
      const card = document.createElement("div")
      card.className = "category-card"
      card.setAttribute("data-category", category.name)

      card.innerHTML = `
              <img src="${category.image}" alt="${category.name}" />
              <h3>${category.name}</h3>
            `

      card.addEventListener("click", () => {
        // Create the selected-category-title element if it doesn't exist
        let categoryTitle = document.getElementById("selected-category-title")
        if (!categoryTitle) {
          categoryTitle = document.createElement("h2")
          categoryTitle.id = "selected-category-title"
          document.body.appendChild(categoryTitle) // Temporary append
        }

        categoryTitle.textContent = category.name

        // Use normalized categories for filtering
        const filteredProducts = allProducts.filter(
          (p) => normalizeCategory(p.category) === normalizeCategory(category.name),
        )

        console.log(`Category clicked: ${category.name}, Products found: ${filteredProducts.length}`)

        // If no products found, try to find similar categories
        if (filteredProducts.length === 0) {
          const similarProducts = findProductsBySimilarCategory(category.name)
          renderCategoryProducts(similarProducts)
        } else {
          renderCategoryProducts(filteredProducts)
        }

        // Scroll to products section
        const categoryProductsSection = document.getElementById("category-products-section")
        if (categoryProductsSection) {
          categoryProductsSection.scrollIntoView({ behavior: "smooth" })
        }
      })

      categoryScroll.appendChild(card)
    })
  }

  function fetchProducts() {
    // Fetch all products from API with ratings and stock information
    fetch("/api/all-products")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok")
        }
        return response.json()
      })
      .then((data) => {
        // Check if data is an array directly or nested in a property
        if (Array.isArray(data)) {
          allProducts = data
        } else if (data.products && Array.isArray(data.products)) {
          allProducts = data.products
        } else if (data.success && data.products && Array.isArray(data.products)) {
          allProducts = data.products
        } else {
          throw new Error("Invalid data format")
        }

        // Debug log to see product categories
        console.log("Product categories:", [...new Set(allProducts.map((p) => p.category))])

        renderCategoryProducts(allProducts)

        // Also render products to the main product grid
        renderProducts(allProducts)
      })
      .catch((error) => {
        console.error("Error fetching products:", error)
        // Fallback to mock data
        allProducts = generateMockProducts()
        renderCategoryProducts(allProducts)

        // Also render products to the main product grid
        renderProducts(allProducts)
      })
  }

  // Function to render products in the main product grid
  function renderProducts(products) {
    const grid = document.getElementById("productGrid")
    if (!grid) return

    grid.innerHTML = ""

    if (!products.length) {
      grid.innerHTML = "<p>No products found.</p>"
      return
    }

    products.forEach((product) => {
      const card = document.createElement("div")
      card.className = "product-card"

      // Add data attributes for each product to the Add to Cart button
      const addToCartBtn = `
            <button class="add-to-cart"
                    data-product-id="${product.id}"
                    data-product-name="${product.product_name}"
                    data-product-price="${product.price}"
                    data-product-image="${product.main_image}">
              Add to Cart
            </button>
          `

      card.innerHTML = `
            <div class="product-image">
              <img src="${product.main_image}" alt="${product.product_name}">
            </div>
            <div class="product-info">
              <h3>${product.product_name}</h3>
              <p class="product-description">${product.product_description}</p>
              <p class="product-price" data-original-price="${product.price}">${
                window.currentSymbol
              }${convertPrice(product.price)}</p>
              <p class="seller">Seller: ${product.seller_name || "Unknown"}</p>
              <div class="product-buttons">
                ${addToCartBtn}
                <button class="buy-now" 
                        data-product-id="${product.id}"
                        data-product-name="${product.product_name}"
                        data-product-price="${product.price}"
                        data-product-image="${product.main_image}">
                  Buy Now
                </button>
              </div>
            </div>
          `

      grid.appendChild(card)
    })
  }

  // Function to find products by similar category
  function findProductsBySimilarCategory(categoryName) {
    const normalizedCategory = normalizeCategory(categoryName)

    // Try to find products with similar category names
    const similarProducts = allProducts.filter((product) => {
      const productCategory = normalizeCategory(product.category)

      // Check if the category contains the search term or vice versa
      return productCategory.includes(normalizedCategory) || normalizedCategory.includes(productCategory)
    })

    // If still no products, return some random products as fallback
    if (similarProducts.length === 0) {
      return allProducts.sort(() => 0.5 - Math.random()).slice(0, 8)
    }

    return similarProducts
  }

  // Add this function to normalize category names
  function normalizeCategory(categoryName) {
    if (!categoryName) return ""

    // Create a mapping of possible category variations
    const categoryMap = {
      electronic: "Electronics",
      electronics: "Electronics",
      tech: "Electronics",
      technology: "Electronics",
      gadget: "Electronics",
      gadgets: "Electronics",

      fashion: "Fashion",
      clothing: "Fashion",
      clothes: "Fashion",
      apparel: "Fashion",
      wear: "Fashion",

      home: "Home",
      homedecor: "Home",
      "home decor": "Home",
      furniture: "Home",
      decor: "Home",

      toy: "Toys",
      toys: "Toys",
      games: "Toys",
      children: "Toys",

      gaming: "Gaming",
      game: "Gaming",
      videogame: "Gaming",
      "video game": "Gaming",
      pc: "Gaming",
      console: "Gaming",

      beauty: "Beauty",
      cosmetics: "Beauty",
      makeup: "Beauty",
      skincare: "Beauty",

      kitchen: "Kitchen",
      cookware: "Kitchen",
      appliances: "Kitchen",
      cooking: "Kitchen",
    }

    const normalized = categoryName.toLowerCase().trim()
    return categoryMap[normalized] || categoryName
  }

  function generateMockProducts() {
    // Generate mock products for demo purposes
    const mockProducts = []
    const categories = ["Electronics", "Fashion", "Home", "Toys", "Beauty", "Kitchen", "Gaming"]
    const images = {
      Electronics: "/static/images/electronics.jpg",
      Fashion: "/static/images/fashion.webp",
      Home: "/static/images/home.webp",
      Toys: "/static/images/toys.jpg",
      Beauty: "/static/images/beauty.jpg",
      Kitchen: "/static/images/kitchen.jpeg",
      Gaming: "/static/images/gaming.jpeg",
    }

    for (let i = 1; i <= 30; i++) {
      const category = categories[Math.floor(Math.random() * categories.length)]
      mockProducts.push({
        id: i,
        product_name: `${category} Product ${i}`,
        product_description: `This is a great ${category.toLowerCase()} product with amazing features.`,
        price: (Math.random() * 100 + 10).toFixed(2),
        category: category,
        main_image: images[category],
        avg_rating: (Math.random() * 5).toFixed(1),
        review_count: Math.floor(Math.random() * 100),
        stock_quantity: Math.random() > 0.2 ? Math.floor(Math.random() * 50) : 0,
        seller_name: `Seller ${Math.floor(Math.random() * 10) + 1}`,
      })
    }

    return mockProducts
  }

  function renderCategoryProducts(products) {
    const grid = document.getElementById("category-products-grid")
    if (!grid) {
      console.error("Category products grid not found")
      return
    }

    grid.innerHTML = ""

    if (!products.length) {
      // Show alert when no products found
      alert("No products found!")
      grid.innerHTML = "<div class='no-products-message'><p>No products found.</p></div>"
      return
    }

    products.forEach((product) => {
      createProductCard(product, grid)
    })
  }

  function createProductCard(product, container) {
    // Normalize the product category for display
    product.displayCategory = normalizeCategory(product.category) || product.category

    const card = document.createElement("div")
    card.className = "product-card"

    // Generate star rating HTML
    const ratingStars = generateRatingStars(product.avg_rating || 0)

    // Convert price to selected currency
    const convertedPrice = convertPrice(product.price)

    // Check if product is in stock
    const isInStock = product.stock_quantity > 0

    // Add data attributes for each product to the Add to Cart button
    const addToCartBtn = `
    <button class="add-to-cart"
            data-product-id="${product.id}"
            data-product-name="${product.product_name}"
            data-product-price="${product.price}"
            data-product-image="${product.main_image}"
            ${!isInStock ? "disabled" : ""}>
      Add to Cart
    </button>
  `

    card.innerHTML = `
    <div class="product-image">
      <img src="${product.main_image}" alt="${product.product_name}" />
    </div>
    <div class="product-info">
      <div class="product-category">${product.displayCategory}</div>
      <h3 class="product-name">${product.product_name}</h3>
      <p class="product-description">${product.product_description}</p>
      
      <div class="product-rating">
        <div class="stars-container">${ratingStars}</div>
        <span class="rating-count">(${product.review_count || 0} reviews)</span>
      </div>
      
      <div class="product-price">
        <span class="current-price" data-original-price="${product.price}">${
          window.currentSymbol
        }${convertedPrice}</span>
      </div>
      <p class="seller">Seller: ${product.seller_name || "Unknown"}</p>
      <p class="stock-info ${!isInStock ? "out-of-stock" : ""}">
        ${!isInStock ? "Out of Stock" : `In Stock: ${product.stock_quantity}`}
      </p>
      <div class="product-buttons">
        ${addToCartBtn}
        <button class="buy-now" 
                data-product-id="${product.id}"
                data-product-name="${product.product_name}"
                data-product-price="${product.price}"
                data-product-image="${product.main_image}"
                ${!isInStock ? "disabled" : ""}>
          Buy Now
        </button>
      </div>
    </div>
  `

    container.appendChild(card)
  }

  function searchProducts(query, category) {
    let filteredProducts = [...allProducts]

    // Filter by category if not "all"
    if (category !== "all") {
      filteredProducts = filteredProducts.filter((p) => normalizeCategory(p.category) === normalizeCategory(category))
    }

    // Filter by search query
    if (query) {
      filteredProducts = filteredProducts.filter(
        (p) =>
          p.product_name.toLowerCase().includes(query) ||
          p.product_description.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query),
      )
    }

    // Update category title
    const categoryTitle = document.getElementById("selected-category-title")
    if (categoryTitle) {
      categoryTitle.textContent = "Search Results"
    }

    // Render filtered products
    renderCategoryProducts(filteredProducts)
  }

  function sortProducts(products, sortBy) {
    const sortedProducts = [...products]

    switch (sortBy) {
      case "price-low":
        sortedProducts.sort((a, b) => Number.parseFloat(a.price) - Number.parseFloat(b.price))
        break
      case "price-high":
        sortedProducts.sort((a, b) => Number.parseFloat(b.price) - Number.parseFloat(a.price))
        break
      default:
        // Default to price-low
        sortedProducts.sort((a, b) => Number.parseFloat(a.price) - Number.parseFloat(b.price))
        break
    }

    renderCategoryProducts(sortedProducts)
  }

  function generateRatingStars(rating) {
    // Handle null or undefined ratings
    rating = Number.parseFloat(rating) || 0

    let stars = ""
    const fullStars = Math.floor(rating)
    const halfStar = rating % 1 >= 0.5
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0)

    for (let i = 0; i < fullStars; i++) {
      stars += '<i class="fas fa-star"></i>'
    }

    if (halfStar) {
      stars += '<i class="fas fa-star-half-alt"></i>'
    }

    for (let i = 0; i < emptyStars; i++) {
      stars += '<i class="far fa-star"></i>'
    }

    return stars
  }

  function updateAllPrices() {
    console.log(`Updating all prices with symbol: ${window.currentSymbol}`)

    // Update prices in category products
    const categoryPrices = document.querySelectorAll("#category-products-grid .current-price")
    categoryPrices.forEach((priceElement) => {
      const originalPrice =
        priceElement.getAttribute("data-original-price") || priceElement.textContent.replace(/[^0-9.]/g, "")
      priceElement.setAttribute("data-original-price", originalPrice)
      priceElement.textContent = `${window.currentSymbol}${convertPrice(originalPrice)}`
    })

    // Update prices in main product grid
    const productPrices = document.querySelectorAll("#productGrid .product-price")
    productPrices.forEach((priceElement) => {
      const originalPrice = priceElement.getAttribute("data-original-price")
      if (originalPrice) {
        priceElement.textContent = `${window.currentSymbol}${convertPrice(originalPrice)}`
      }
    })

    // Update prices in cart
    updateCartDisplay()
  }

  function addToCart(product) {
    // Check if product is in stock
    if (product.stock_quantity <= 0) {
      showToast(`${product.product_name} is out of stock!`)
      return
    }

    // Check if product is already in cart
    const existingItem = cart.find((item) => item.id === product.id)

    if (existingItem) {
      existingItem.quantity += 1
    } else {
      cart.push({
        id: product.id,
        name: product.product_name,
        price: product.price,
        image: product.main_image,
        quantity: 1,
        stock: product.stock_quantity,
      })
    }

    // Save cart to localStorage
    saveCart()

    // Update cart badge
    updateCartBadge()

    // Update cart display
    updateCartDisplay()

    // Show confirmation
    showToast(`${product.product_name} added to cart!`)
  }

  function removeFromCart(productId) {
    cart = cart.filter((item) => item.id !== productId)

    // Save cart to localStorage
    saveCart()

    // Update cart badge
    updateCartBadge()

    // Update cart display
    updateCartDisplay()
  }

  function updateCartQuantity(productId, newQuantity) {
    const item = cart.find((item) => item.id === productId)

    if (item) {
      item.quantity = Math.max(1, newQuantity)

      // Save cart to localStorage
      saveCart()

      // Update cart display
      updateCartDisplay()
    }
  }

  function updateCartBadge() {
    const cartBadge = document.getElementById("cart-badge")
    if (!cartBadge) return

    const totalItems = cart.reduce((total, item) => total + item.quantity, 0)
    cartBadge.textContent = totalItems

    if (totalItems > 0) {
      cartBadge.classList.add("has-items")
    } else {
      cartBadge.classList.remove("has-items")
    }
  }

  function updateCartDisplay() {
    const cartItems = document.getElementById("cart-items")
    const cartTotal = document.getElementById("cart-total")
    if (!cartItems || !cartTotal) return

    cartItems.innerHTML = ""

    if (cart.length === 0) {
      cartItems.innerHTML = "<p>Your cart is empty.</p>"
      cartTotal.textContent = `${window.currentSymbol}0.00`
      return
    }

    let total = 0

    cart.forEach((item) => {
      const convertedPrice = convertPrice(item.price)
      const itemTotal = Number.parseFloat(convertedPrice) * item.quantity
      total += itemTotal

      const cartItem = document.createElement("div")
      cartItem.className = "cart-item"

      cartItem.innerHTML = `
              <div class="cart-item-image">
                <img src="${item.image}" alt="${item.name}" />
              </div>
              <div class="cart-item-details">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${window.currentSymbol}${convertedPrice}</div>
                <div class="cart-item-quantity">
                  <button class="quantity-btn minus" data-id="${item.id}">-</button>
                  <span>${item.quantity}</span>
                  <button class="quantity-btn plus" data-id="${item.id}">+</button>
                </div>
              </div>
              <button class="cart-item-remove" data-id="${item.id}">
                <i class="fas fa-trash"></i>
              </button>
            `

      // Add event listeners
      const minusBtn = cartItem.querySelector(".minus")
      const plusBtn = cartItem.querySelector(".plus")
      const removeBtn = cartItem.querySelector(".cart-item-remove")

      minusBtn.addEventListener("click", () => {
        updateCartQuantity(item.id, item.quantity - 1)
      })

      plusBtn.addEventListener("click", () => {
        updateCartQuantity(item.id, item.quantity + 1)
      })

      removeBtn.addEventListener("click", () => {
        removeFromCart(item.id)
      })

      cartItems.appendChild(cartItem)
    })

    cartTotal.textContent = `${window.currentSymbol}${total.toFixed(2)}`
  }

  function saveCart() {
    localStorage.setItem("bazaar_cart", JSON.stringify(cart))
  }

  function loadCart() {
    const savedCart = localStorage.getItem("bazaar_cart")
    if (savedCart) {
      cart = JSON.parse(savedCart)
      updateCartBadge()
      updateCartDisplay()
    }
  }

  function showToast(message) {
    // Create toast element
    const toast = document.createElement("div")
    toast.className = "toast"
    toast.textContent = message

    // Add to body
    document.body.appendChild(toast)

    // Show toast
    setTimeout(() => {
      toast.classList.add("show")
    }, 100)

    // Hide and remove toast
    setTimeout(() => {
      toast.classList.remove("show")
      setTimeout(() => {
        document.body.removeChild(toast)
      }, 300)
    }, 3000)
  }

  // Add event listeners for cart item buttons
  document.addEventListener("click", (e) => {
    // Handle quantity buttons in cart
    if (e.target.classList.contains("minus") || e.target.classList.contains("plus")) {
      const productId = e.target.getAttribute("data-id")
      if (!productId) return

      const cartItem = cart.find((item) => item.id === productId)
      if (cartItem) {
        if (e.target.classList.contains("minus") && cartItem.quantity > 1) {
          updateCartQuantity(productId, cartItem.quantity - 1)
        } else if (e.target.classList.contains("plus")) {
          updateCartQuantity(productId, cartItem.quantity + 1)
        }
      }
    }

    // Handle remove button in cart
    if (
      e.target.classList.contains("cart-item-remove") ||
      (e.target.parentElement && e.target.parentElement.classList.contains("cart-item-remove"))
    ) {
      const productId =
        e.target.getAttribute("data-id") ||
        (e.target.parentElement ? e.target.parentElement.getAttribute("data-id") : null)

      if (productId) {
        removeFromCart(productId)
      }
    }

    // Handle buy now button
    if (e.target.classList.contains("buy-now")) {
      // Directly redirect to cart page
      window.location.href = "/cart"
    }
  })
})

// Add toast styles to the page
const style = document.createElement("style")
style.textContent = `
        .toast {
          position: fixed;
          bottom: 20px;
          left: 50%;
          transform: translateX(-50%) translateY(100px);
          background-color: rgba(0, 0, 0, 0.8);
          color: white;
          padding: 12px 24px;
          border-radius: 4px;
          z-index: 9999;
          opacity: 0;
          transition: transform 0.3s, opacity 0.3s;
        }
        
        .toast.show {
          transform: translateX(-50%) translateY(0);
          opacity: 1;
        }
      
        .no-products-message {
          text-align: center;
          margin-bottom: 2rem;
          padding: 1rem;
          background-color: #f8f9fa;
          border-radius: 8px;
        }
        
        .fallback-product {
          border-left: 3px solid var(--primary-color);
        }
      
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-color: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(5px);
          z-index: 1000;
          display: none;
        }
      `
document.head.appendChild(style)

// Add styles for ratings and stock info
const ratingAndStockStyles = document.createElement("style")
ratingAndStockStyles.textContent = `
  .product-rating {
    display: flex;
    align-items: center;
    margin: 8px 0;
  }
  
  .stars-container {
    color: #ffc107;
    margin-right: 5px;
  }
  
  .rating-count {
    font-size: 0.85rem;
    color: #6c757d;
  }
  
  .stock-info {
    margin: 8px 0;
    font-size: 0.9rem;
    font-weight: 500;
    color: #28a745;
  }
  
  .stock-info.out-of-stock {
    color: #dc3545;
    font-weight: bold;
  }
  
  .product-buttons button:disabled {
    background-color: #e9ecef;
    color: #6c757d;
    cursor: not-allowed;
    border-color: #dee2e6;
  }
`
document.head.appendChild(ratingAndStockStyles)
