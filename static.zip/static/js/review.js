document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("search-input");
  const ratingFilter = document.getElementById("rating-filter");
  const reviewCards = document.querySelectorAll(".review-card");

  // Function to filter reviews
  function filterReviews() {
    const searchTerm = searchInput.value.toLowerCase();
    const selectedRating = ratingFilter.value;

    reviewCards.forEach((card) => {
      const productName = card
        .querySelector(".product-name")
        .textContent.toLowerCase();
      const reviewText = card
        .querySelector(".review-text")
        .textContent.toLowerCase();
      const rating = card.getAttribute("data-rating");

      const matchesSearch =
        productName.includes(searchTerm) || reviewText.includes(searchTerm);
      const matchesRating =
        selectedRating === "all" || rating === selectedRating;

      if (matchesSearch && matchesRating) {
        card.style.display = "";
      } else {
        card.style.display = "none";
      }
    });
  }

  // Event listeners for search and filter
  searchInput.addEventListener("input", filterReviews);
  ratingFilter.addEventListener("change", filterReviews);

  // Handle reply buttons
  document.querySelectorAll(".reply-button").forEach((button) => {
    button.addEventListener("click", function () {
      const replyForm = this.nextElementSibling;
      replyForm.classList.remove("hidden");
    });
  });

  // Handle cancel reply buttons
  document.querySelectorAll(".cancel-reply-button").forEach((button) => {
    button.addEventListener("click", function () {
      const replyForm = this.closest(".reply-form");
      replyForm.classList.add("hidden");
    });
  });

  // Handle submit reply buttons
  document.querySelectorAll(".submit-reply-button").forEach((button) => {
    button.addEventListener("click", function () {
      const replyForm = this.closest(".reply-form");
      const textarea = replyForm.querySelector(".reply-textarea");
      const replyText = textarea.value.trim();
      const reviewId = replyForm
        .closest(".review-card")
        .querySelector(".reply-button").dataset.reviewId;

      if (replyText) {
        // Submit reply to backend
        fetch("/submit-review-reply", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            review_id: reviewId,
            reply_text: replyText,
          }),
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              // Create seller reply section
              const sellerReply = document.createElement("div");
              sellerReply.className = "seller-reply";
              sellerReply.innerHTML = `
                            <p class="reply-label">Your Response:</p>
                            <p class="reply-text">${data.reply.text}</p>
                            <span class="reply-date">• ${data.reply.created_at}</span>
                            <button class="edit-reply-button" data-reply-id="${data.reply.id}"></button>
                        `;

              // Replace reply form with seller reply
              replyForm.parentNode.replaceChild(sellerReply, replyForm);
            } else {
              alert(data.error || "Failed to submit reply");
            }
          })
          .catch((error) => {
            console.error("Error:", error);
            alert("An error occurred while submitting the reply");
          });
      }
    });
  });

  // Handle edit reply buttons
  document.querySelectorAll(".edit-reply-button").forEach((button) => {
    button.addEventListener("click", function () {
      const replyId = this.dataset.replyId;
      const sellerReply = this.closest(".seller-reply");
      const replyText = sellerReply.querySelector(".reply-text").textContent;

      // Create reply form
      const replyForm = document.createElement("div");
      replyForm.className = "reply-form";
      replyForm.innerHTML = `
                <textarea class="reply-textarea">${replyText}</textarea>
                <div class="reply-actions">
                    <button class="submit-reply-button" data-reply-id="${replyId}">Update Reply</button>
                    <button class="cancel-reply-button">Cancel</button>
                </div>
            `;

      // Replace seller reply with form
      sellerReply.parentNode.replaceChild(replyForm, sellerReply);
    });
  });
});
