// Validate login form
document.getElementById("loginForm")?.addEventListener("submit", function(event) {
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value.trim();

    if (email === "" || password === "") {
        alert("Please fill in all fields.");
        event.preventDefault();
    }
});
