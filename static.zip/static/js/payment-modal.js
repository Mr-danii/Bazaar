document.addEventListener("DOMContentLoaded", () => {
  // Create modal overlay for blurring the background
  const modalOverlay = document.createElement("div");
  modalOverlay.className = "modal-overlay";
  document.body.appendChild(modalOverlay);

  // Create notification element
  const notification = document.createElement("div");
  notification.className = "notification";
  notification.innerHTML = `
      <div class="notification-content">
        <i class="fas fa-check-circle"></i>
        <span id="notification-message"></span>
      </div>
    `;
  document.body.appendChild(notification);

  // Create payment modal
  const paymentModal = document.createElement("div");
  paymentModal.id = "paymentModal";
  paymentModal.className = "payment-modal";
  paymentModal.innerHTML = `
      <div class="payment-header">
        <h3>Select Payment Method</h3>
        <span class="close-btn" id="closePaymentModal">&times;</span>
      </div>
      <div class="payment-notification" id="paymentNotification">
        <i class="fas fa-check-circle"></i>
        <span id="paymentNotificationMessage"></span>
      </div>
      <div class="payment-modal-content">
        <div class="payment-layout">
          <div class="payment-methods-column">
            <div class="payment-methods">
              <div class="payment-method active" data-method="cod">
                <input type="radio" name="payment-method" id="cod" value="cod" checked>
                <label for="cod">
                  <i class="fas fa-money-bill-wave"></i>
                  <span>Cash on Delivery</span>
                </label>
              </div>
              <div class="payment-method" data-method="credit-card">
                <input type="radio" name="payment-method" id="credit-card" value="credit-card">
                <label for="credit-card">
                  <i class="fas fa-credit-card"></i>
                  <span>Credit Card</span>
                </label>
              </div>
            </div>
            
            <div class="order-summary">
              <h4>Order Summary</h4>
              <div class="summary-row">
                <span>Subtotal:</span>
                <span id="modal-subtotal">$0.00</span>
              </div>
              <div class="summary-row">
                <span>Shipping:</span>
                <span>$5.00</span>
              </div>
              <div class="summary-row total">
                <span>Total:</span>
                <span id="modal-total">$0.00</span>
              </div>
            </div>
          </div>
          
          <div class="credit-card-column">
            <div class="credit-card-details" id="creditCardDetails">
              <div class="form-group">
                <label for="card-number">Card Number</label>
                <input type="text" id="card-number" placeholder="1234 5678 9012 3456" maxlength="19">
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label for="expiry-date">Expiry Date</label>
                  <input type="text" id="expiry-date" placeholder="MM/YY" maxlength="5">
                </div>
                <div class="form-group">
                  <label for="cvv">CVV</label>
                  <input type="text" id="cvv" placeholder="123" maxlength="3">
                </div>
              </div>
              <div class="form-group">
                <label for="card-name">Name on Card</label>
                <input type="text" id="card-name" placeholder="John Doe">
              </div>
            </div>
          </div>
        </div>
  
        <div class="payment-buttons">
          <button class="checkout-btn" id="completeCheckoutBtn" disabled>Complete Checkout</button>
        </div>
      </div>
    `;
  document.body.appendChild(paymentModal);

  // Get elements
  const checkoutBtn = document.querySelector(".checkout-btn");
  const closeBtn = document.getElementById("closePaymentModal");
  const completeCheckoutBtn = document.getElementById("completeCheckoutBtn");
  const paymentMethods = document.querySelectorAll(".payment-method");
  const creditCardDetails = document.getElementById("creditCardDetails");
  const paymentNotification = document.getElementById("paymentNotification");
  const paymentNotificationMessage = document.getElementById(
    "paymentNotificationMessage"
  );

  // Listen for openPaymentModal event
  window.addEventListener("openPaymentModal", () => {
    openPaymentModal();
  });

  // Function to open payment modal
  function openPaymentModal() {
    // Update order summary in modal
    const subtotal = document.getElementById("cartTotal").textContent;
    document.getElementById("modal-subtotal").textContent = subtotal;

    // Calculate total (subtotal + shipping)
    const subtotalValue = Number.parseFloat(subtotal.replace(/[^0-9.-]+/g, ""));
    const shippingValue = 5.0;
    const totalValue = subtotalValue + shippingValue;

    // Get current currency symbol
    const currencySymbol = window.currentSymbol || "$";
    document.getElementById(
      "modal-total"
    ).textContent = `${currencySymbol}${totalValue.toFixed(2)}`;

    // Show modal and overlay
    paymentModal.style.display = "block";
    modalOverlay.style.display = "block";

    // Ensure modal is centered
    paymentModal.style.top = "50%";
    paymentModal.style.left = "50%";
    paymentModal.style.transform = "translate(-50%, -50%)";
  }

  // Add event listener to checkout button
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
      openPaymentModal();
    });
  }

  // Close modal button
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      closePaymentModal();
    });
  }

  // Close when clicking outside the modal
  modalOverlay.addEventListener("click", () => {
    closePaymentModal();
  });

  // Payment method selection
  paymentMethods.forEach((method) => {
    method.addEventListener("click", () => {
      // Remove active class from all methods
      paymentMethods.forEach((m) => m.classList.remove("active"));

      // Add active class to selected method
      method.classList.add("active");

      // Check the radio button
      const radio = method.querySelector("input[type='radio']");
      radio.checked = true;

      // Show/hide credit card details
      if (method.dataset.method === "credit-card") {
        creditCardDetails.style.display = "block";
        document.querySelector(".credit-card-column").style.display = "block";
        // Only enable checkout button if card details are valid
        validateCardDetails();
      } else {
        creditCardDetails.style.display = "none";
        document.querySelector(".credit-card-column").style.display = "none";
        // Enable checkout button for COD
        completeCheckoutBtn.disabled = false;
      }
    });
  });

  // Credit card validation
  const cardNumber = document.getElementById("card-number");
  const expiryDate = document.getElementById("expiry-date");
  const cvv = document.getElementById("cvv");
  const cardName = document.getElementById("card-name");

  // Format card number as user types (add spaces)
  cardNumber.addEventListener("input", (e) => {
    const value = e.target.value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    let formattedValue = "";

    for (let i = 0; i < value.length; i++) {
      if (i > 0 && i % 4 === 0) {
        formattedValue += " ";
      }
      formattedValue += value[i];
    }

    e.target.value = formattedValue;
    validateCardDetails();
  });

  // Format expiry date as user types (add slash)
  expiryDate.addEventListener("input", (e) => {
    let value = e.target.value.replace(/[^0-9]/gi, "");

    if (value.length > 2) {
      value = value.substring(0, 2) + "/" + value.substring(2, 4);
    }

    e.target.value = value;
    validateCardDetails();
  });

  // Validate CVV (numbers only)
  cvv.addEventListener("input", (e) => {
    e.target.value = e.target.value.replace(/[^0-9]/gi, "");
    validateCardDetails();
  });

  // Validate card name
  cardName.addEventListener("input", () => {
    validateCardDetails();
  });

  // Validate all card details
  function validateCardDetails() {
    const isCardNumberValid =
      cardNumber.value.replace(/\s+/g, "").length === 16;
    const isExpiryValid = /^\d{2}\/\d{2}$/.test(expiryDate.value);
    const isCvvValid = cvv.value.length === 3;
    const isNameValid = cardName.value.trim().length > 0;

    // Only enable checkout button if all fields are valid
    if (
      document.querySelector(".payment-method.active").dataset.method ===
      "credit-card"
    ) {
      completeCheckoutBtn.disabled = !(
        isCardNumberValid &&
        isExpiryValid &&
        isCvvValid &&
        isNameValid
      );
    }
  }

  // Complete checkout button
  completeCheckoutBtn.addEventListener("click", async () => {
    const selectedMethod = document.querySelector(".payment-method.active")
      .dataset.method;

    try {
      // Prepare payment data
      const paymentData = {
        payment_method:
          selectedMethod === "cod" ? "Cash on Delivery" : "Credit Card",
        // Add credit card details if needed (in a real app, you'd handle this securely)
      };

      // Send order to server
      const response = await fetch("/place-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(paymentData),
      });

      const data = await response.json();

      if (data.success) {
        // Show success notification in modal
        showPaymentNotification("Your order has been placed successfully!");

        // Clear cart in localStorage
        localStorage.setItem("bazaar_cart", JSON.stringify([]));

        // Update cart badge
        updateCartBadges([]);

        // Broadcast the update to other components
        broadcastCartUpdate();

        // Close modal after 2 seconds
        setTimeout(() => {
          closePaymentModal();

          // Clear cart items container immediately
          const cartItemsContainer =
            document.getElementById("cartItemsContainer");
          if (cartItemsContainer) {
            cartItemsContainer.innerHTML = `
                <div class="empty-cart">
                  <i class="fas fa-shopping-cart"></i>
                  <p>Your cart is empty</p>
                </div>
              `;
          }

          // Update item count and total
          const cartItemCount = document.getElementById("cartItemCount");
          const cartTotal = document.getElementById("cartTotal");
          if (cartItemCount) cartItemCount.textContent = "0";

          // Get current currency symbol
          const currencySymbol = window.currentSymbol || "$";
          if (cartTotal) cartTotal.textContent = `${currencySymbol}0.00`;

          // Disable checkout button
          const checkoutBtn = document.querySelector(".checkout-btn");
          if (checkoutBtn) checkoutBtn.disabled = true;

          // Refresh the cart by re-fetching data
          if (typeof window.fetchCartDetails === "function") {
            window.fetchCartDetails();
          }
        }, 2000);
      } else {
        showPaymentNotification(
          "Failed to place order. Please try again.",
          "error"
        );
      }
    } catch (error) {
      console.error("Error placing order:", error);
      showPaymentNotification(
        "An error occurred while placing the order.",
        "error"
      );
    }
  });

  // Function to show notification in payment modal
  function showPaymentNotification(message, type = "success") {
    paymentNotificationMessage.textContent = message;
    paymentNotification.className = `payment-notification ${type}`;
    paymentNotification.classList.add("show");

    // Hide notification after 3 seconds
    setTimeout(() => {
      paymentNotification.classList.remove("show");
    }, 3000);
  }

  // Function to close payment modal
  function closePaymentModal() {
    paymentModal.style.display = "none";
    modalOverlay.style.display = "none";

    // Reset form
    document.getElementById("cod").checked = true;
    document
      .querySelectorAll(".payment-method")
      .forEach((m) => m.classList.remove("active"));
    document.querySelector("[data-method='cod']").classList.add("active");
    creditCardDetails.style.display = "none";
    document.querySelector(".credit-card-column").style.display = "none";

    // Clear credit card fields
    cardNumber.value = "";
    expiryDate.value = "";
    cvv.value = "";
    cardName.value = "";
  }

  // Function to show notification
  function showNotification(message, type = "success") {
    const notificationMessage = document.getElementById("notification-message");
    notificationMessage.textContent = message;
    notification.className = `notification ${type}`;
    notification.classList.add("show");

    // Hide notification after 3 seconds
    setTimeout(() => {
      notification.classList.remove("show");
    }, 3000);
  }

  // Initialize - hide credit card column by default
  document.querySelector(".credit-card-column").style.display = "none";

  // Handle window resize to ensure modal stays centered
  window.addEventListener("resize", () => {
    if (paymentModal.style.display === "block") {
      paymentModal.style.top = "50%";
      paymentModal.style.left = "50%";
      paymentModal.style.transform = "translate(-50%, -50%)";
    }
  });

  // Mock functions to resolve undeclared variable errors.  These should be replaced with actual implementations.
  function updateCartBadges(cart) {
    console.warn(
      "updateCartBadges function is a placeholder. Implement the actual logic."
    );
  }

  function broadcastCartUpdate() {
    console.warn(
      "broadcastCartUpdate function is a placeholder. Implement the actual logic."
    );
  }

  function fetchCartDetails() {
    console.warn(
      "fetchCartDetails function is a placeholder. Implement the actual logic."
    );
  }
});
