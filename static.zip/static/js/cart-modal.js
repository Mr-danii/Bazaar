document.addEventListener("DOMContentLoaded", () => {
  // Create modal overlay for blurring the background
  const modalOverlay = document.createElement("div");
  modalOverlay.className = "modal-overlay";
  document.body.appendChild(modalOverlay);

  // Create cart modal
  const cartModal = document.createElement("div");
  cartModal.id = "cartModal";
  cartModal.className = "cart-modal";
  cartModal.innerHTML = `
    <div class="cart-header">
      <h3>Add to Cart</h3>
      <span class="close-btn" id="closeCartModal">&times;</span>
    </div>
    <div class="cart-notification" id="cartNotification">
      <i class="fas fa-check-circle"></i>
      <span id="notificationMessage">Product added to cart successfully!</span>
    </div>
    <div class="cart-modal-content">
      <img id="cartImage" src="/placeholder.svg" alt="Product Image" class="product-img">
      <h2 id="cartProductName"></h2>
      <p id="cartPrice"></p>

      <div class="quantity-container">
        <button id="decreaseBtn">-</button>
        <input type="number" id="cartQuantity" value="1" min="1">
        <button id="increaseBtn">+</button>
      </div>

      <div class="cart-buttons">
        <button class="checkout-btn" id="submitCartBtn">Add to Cart</button>
      </div>
    </div>
  `;
  document.body.appendChild(cartModal);

  // Get notification element
  const cartNotification = document.getElementById("cartNotification");
  const notificationMessage = document.getElementById("notificationMessage");

  let selectedProduct = {};

  // Add event listener to dynamic "Add to Cart" buttons on the product cards
  document.addEventListener("click", (e) => {
    if (e.target.classList.contains("add-to-cart")) {
      // Get product details from button data attributes
      selectedProduct = {
        id: e.target.getAttribute("data-product-id"),
        name: e.target.getAttribute("data-product-name"),
        price: e.target.getAttribute("data-product-price"),
        image: e.target.getAttribute("data-product-image"),
      };

      // Update modal content with current currency symbol
      document.getElementById("cartProductName").textContent =
        selectedProduct.name;

      // Use the global currency symbol and conversion
      const convertedPrice = window.convertPrice
        ? window.convertPrice(selectedProduct.price)
        : selectedProduct.price;
      const currencySymbol = window.currentSymbol || "$";

      document.getElementById(
        "cartPrice"
      ).textContent = `Price: ${currencySymbol}${convertedPrice}`;
      document.getElementById("cartImage").src = selectedProduct.image;
      document.getElementById("cartQuantity").value = "1";

      // Hide notification if it was visible
      cartNotification.classList.remove("show");

      // Show modal and overlay
      cartModal.style.display = "block";
      modalOverlay.style.display = "block";

      // Ensure modal is centered
      cartModal.style.top = "50%";
      cartModal.style.left = "50%";
      cartModal.style.transform = "translate(-50%, -50%)";
    }
  });

  // Set up quantity buttons
  const decreaseBtn = document.getElementById("decreaseBtn");
  const increaseBtn = document.getElementById("increaseBtn");
  const quantityInput = document.getElementById("cartQuantity");
  const closeBtn = document.getElementById("closeCartModal");
  const submitBtn = document.getElementById("submitCartBtn");

  decreaseBtn.addEventListener("click", () => {
    const currentValue = Number.parseInt(quantityInput.value);
    if (currentValue > 1) {
      quantityInput.value = (currentValue - 1).toString();
    }
  });

  increaseBtn.addEventListener("click", () => {
    const currentValue = Number.parseInt(quantityInput.value);
    quantityInput.value = (currentValue + 1).toString();
  });

  // Close modal button
  closeBtn.addEventListener("click", () => {
    closeCart();
  });

  // Close when clicking outside the modal
  modalOverlay.addEventListener("click", () => {
    closeCart();
  });

  // Function to show notification within the modal
  function showNotification(message) {
    notificationMessage.textContent = message;
    cartNotification.classList.add("show");

    // Hide notification after 3 seconds
    setTimeout(() => {
      cartNotification.classList.remove("show");
    }, 3000);
  }

  // Handle cart submission - Now shows notification within the modal
  submitBtn.addEventListener("click", () => {
    const quantity = Number.parseInt(quantityInput.value);

    // Validate quantity is a positive number
    if (isNaN(quantity) || quantity <= 0) {
      showNotification("Please enter a valid quantity");
      return;
    }

    // Try to use the API first
    fetch("/add-to-cart", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        product_id: selectedProduct.id,
        quantity: quantity,
      }),
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("Network response was not ok");
        }
        return res.json();
      })
      .then((data) => {
        if (data.message) {
          // Update cart in localStorage and UI
          addToLocalCart(selectedProduct, quantity);
          showNotification(data.message);

          // Don't close the cart modal, just show the notification
        } else if (data.error) {
          showNotification("Error: " + data.error);
        }
      })
      .catch((error) => {
        console.error("Error adding to cart:", error);

        // Fallback to local cart if API fails
        addToLocalCart(selectedProduct, quantity);
        showNotification("Product added to cart successfully!");
      });
  });

  // Function to add to cart and update badge
  function addToLocalCart(product, quantity) {
    // Get existing cart from localStorage
    const cart = JSON.parse(localStorage.getItem("bazaar_cart")) || [];

    // Check if product already exists in cart
    const existingItemIndex = cart.findIndex((item) => item.id === product.id);

    if (existingItemIndex !== -1) {
      // Update quantity if product exists
      cart[existingItemIndex].quantity += quantity;
    } else {
      // Add new product to cart
      cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        quantity: quantity,
      });
    }

    // Save updated cart to localStorage
    localStorage.setItem("bazaar_cart", JSON.stringify(cart));

    // Update cart badge - calculate the exact total
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    const cartBadge = document.getElementById("cart-badge");
    if (cartBadge) {
      cartBadge.textContent = totalItems.toString();

      if (totalItems > 0) {
        cartBadge.classList.add("has-items");
      } else {
        cartBadge.classList.remove("has-items");
      }
    }

    // Debug log to verify the count
    console.log(
      "Cart updated. Total items:",
      totalItems,
      "Cart contents:",
      cart
    );
  }

  // Function to close the cart modal
  function closeCart() {
    cartModal.style.display = "none";
    modalOverlay.style.display = "none";
  }

  // Load cart on page load and update badge
  const savedCart = JSON.parse(localStorage.getItem("bazaar_cart")) || [];
  console.log("Initial cart load:", savedCart);

  // Update cart badge on initial load
  const totalItems = savedCart.reduce(
    (total, item) => total + item.quantity,
    0
  );
  const cartBadge = document.getElementById("cart-badge");
  if (cartBadge) {
    cartBadge.textContent = totalItems.toString();
    if (totalItems > 0) {
      cartBadge.classList.add("has-items");
    }
  }

  // Handle window resize to ensure modal stays centered
  window.addEventListener("resize", () => {
    if (cartModal.style.display === "block") {
      cartModal.style.top = "50%";
      cartModal.style.left = "50%";
      cartModal.style.transform = "translate(-50%, -50%)";
    }
  });
});
