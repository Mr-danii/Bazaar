// Global variables
let allOrders = []; // Global to store fetched orders
let currentOrderId = null;
let currentSellerId = null;
let chatVisible = false;
let currentUserId = null;
let activeReviewModal = null; // Track active review modal to prevent duplicates

// Function to check session status
async function checkSession() {
  try {
    const response = await fetch("/api/check-session", {
      credentials: "include",
    });
    const data = await response.json();
    if (!data.success) {
      window.location.href = "/login";
      return false;
    }
    return true;
  } catch (error) {
    console.error("Error checking session:", error);
    window.location.href = "/login";
    return false;
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  // Check session first
  const isLoggedIn = await checkSession();
  if (!isLoggedIn) return;

  // Fetch orders
  fetch("/get-my-orders")
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        allOrders = data.orders;
        console.log("Fetched orders in myorder.js:", allOrders);
        displayOrders(allOrders);
      } else {
        showCustomAlert("Failed to fetch orders.");
      }
    })
    .catch((error) => {
      console.error("Error fetching orders:", error);
      showCustomAlert("Failed to load orders.");
    });

  // Fetch current user ID for chat functionality
  fetch("/api/get-current-user")
    .then((response) => response.json())
    .then((data) => {
      if (data.success && data.user) {
        currentUserId = data.user.id;
      } else {
        console.error(
          "Error: Could not get current user ID from API response:",
          data
        );
      }
    })
    .catch((error) => {
      console.error("Error getting current user:", error);
    });

  // Set up message input listener for chat
  const messageInput = document.getElementById("messageInput");
  if (messageInput) {
    messageInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        sendMessage();
      }
    });
  }

  // Set up hamburger menu
  const hamburger = document.getElementById("hamburgerMenu");
  const nav = document.querySelector(".header-nav");
  if (hamburger && nav) {
    hamburger.addEventListener("click", () => {
      nav.classList.toggle("open");
    });

    document.addEventListener("click", (e) => {
      if (!hamburger.contains(e.target) && !nav.contains(e.target)) {
        nav.classList.remove("open");
      }
    });
  }

  // Add click event to chat backdrop to close chat
  const chatBackdrop = document.getElementById("chatBackdrop");
  if (chatBackdrop) {
    chatBackdrop.addEventListener("click", () => {
      toggleChat();
    });
  }

  // Custom Alert Box
  function showCustomAlert(message) {
    const alertBox = document.createElement("div");
    alertBox.className = "custom-alert";
    alertBox.innerHTML = `
      <div class="custom-alert-content">
        <div class="custom-alert-header">
          <i class="fas fa-info-circle"></i>
          <span>Alert</span>
        </div>
        <div class="custom-alert-body">
          <p>${message}</p>
        </div>
        <div class="custom-alert-footer">
          <button class="custom-alert-btn">OK</button>
        </div>
      </div>
    `;

    document.body.appendChild(alertBox);

    // Prevent scrolling while alert is open
    document.body.style.overflow = "hidden";

    // Close alert on button click
    alertBox
      .querySelector(".custom-alert-btn")
      .addEventListener("click", () => {
        document.body.removeChild(alertBox);
        document.body.style.overflow = "";
      });

    // Close alert on click outside
    alertBox.addEventListener("click", (e) => {
      if (e.target === alertBox) {
        document.body.removeChild(alertBox);
        document.body.style.overflow = "";
      }
    });
  }

  // Custom Confirm Box
  function showCustomConfirm(message, onConfirm, onCancel) {
    const confirmBox = document.createElement("div");
    confirmBox.className = "custom-confirm";
    confirmBox.innerHTML = `
      <div class="custom-confirm-content">
        <div class="custom-confirm-header">
          <i class="fas fa-question-circle"></i>
          <span>Confirm</span>
        </div>
        <div class="custom-confirm-body">
          <p>${message}</p>
        </div>
        <div class="custom-confirm-footer">
          <button class="custom-confirm-cancel-btn">Cancel</button>
          <button class="custom-confirm-ok-btn">OK</button>
        </div>
      </div>
    `;

    document.body.appendChild(confirmBox);

    // Prevent scrolling while confirm is open
    document.body.style.overflow = "hidden";

    // Handle confirm button
    confirmBox
      .querySelector(".custom-confirm-ok-btn")
      .addEventListener("click", () => {
        document.body.removeChild(confirmBox);
        document.body.style.overflow = "";
        if (typeof onConfirm === "function") onConfirm();
      });

    // Handle cancel button
    confirmBox
      .querySelector(".custom-confirm-cancel-btn")
      .addEventListener("click", () => {
        document.body.removeChild(confirmBox);
        document.body.style.overflow = "";
        if (typeof onCancel === "function") onCancel();
      });

    // Handle click outside
    confirmBox.addEventListener("click", (e) => {
      if (e.target === confirmBox) {
        document.body.removeChild(confirmBox);
        document.body.style.overflow = "";
        if (typeof onCancel === "function") onCancel();
      }
    });
  }

  // Display orders in the UI
  function displayOrders(orders) {
    const container = document.getElementById("ordersList");
    if (!container) {
      console.error(
        "#ordersList element not found for displayOrders in myorder.js"
      );
      return;
    }
    container.innerHTML = "";

    if (!orders || orders.length === 0) {
      container.innerHTML = "<p>No orders found.</p>";
      return;
    }

    orders.forEach((order) => {
      const card = document.createElement("div");
      card.className = "order-item";

      const productImage =
        order.image_01 && order.image_01 !== "Unknown"
          ? `<img src="${order.image_01}" alt="${
              order.product_name || "Product"
            }" class="product-image" style="max-width: 160px;">`
          : `<img src="static/images/default-product.jpg" alt="Default image" class="product-image" style="max-width: 160px;">`;

      // Review Button Logic - Check if review exists and disable if it does
      const isDelivered =
        order.state && order.state.toLowerCase() === "delivered";
      const hasReview = order.review ? true : false;

      let reviewButton = "";
      if (isDelivered) {
        if (hasReview) {
          // Disabled button with different styling
          reviewButton = `<button class="review-btn" disabled style="background-color: #cccccc; cursor: not-allowed;">
          <i class="fas fa-star"></i> Review Added
        </button>`;
        } else {
          // Active button
          reviewButton = `<button class="review-btn" data-order-id="${order.order_id}" data-product-id="${order.product_id}">
          <i class="fas fa-star"></i> Add Review
        </button>`;
        }
      }

      // Message Seller Button Logic
      const messageButton = order.seller_id
        ? `<button class="message-btn" data-order-id="${order.order_id}" data-seller-id="${order.seller_id}">
             <i class="fas fa-comment"></i> Message Seller
       </button>`
        : "";

      // Rest of your card HTML remains the same
      card.innerHTML = `
        <div class="order-header">
            <div class="order-info">
                <h5>Order #${order.order_id}</h5>
                <p class="order-date">Date: ${order.order_date || "N/A"}</p>
            </div>
            <div class="order-actions">
                ${messageButton} 
                ${reviewButton} 
            </div>
        </div>
        <div class="order-details">
            <div class="product-image-container">${productImage}</div>
            <div class="product-info">
                <p><strong>Payment Method:</strong> ${
                  order.payment_method || "N/A"
                }</p>
                <p><strong>Product ID:</strong> ${order.product_id || "N/A"}</p>
                <p><strong>Product Name:</strong> ${
                  order.product_name || "N/A"
                }</p>
                <p><strong>State:</strong> <span class="order-status ${getStatusClass(
                  order.state
                )}">${order.state || "N/A"}</span></p>
            </div>
        </div>
        ${
          order.review
            ? `
          <div class="review-section" style="margin-top: 15px; border-top: 1px solid #eee; padding-top: 10px;">
              <h6>Your Review (${
                order.review.rating
              } <i class="fas fa-star" style="color: #ffd700;"></i>)</h6>
              <p>${order.review.comment || "No comment provided."}</p>
              <small>Reviewed on: ${order.review.created_at}</small>
              ${
                order.review.replies && order.review.replies.length > 0
                  ? `
                  <div class="reply-section" style="margin-left: 20px; margin-top: 10px; border-left: 2px solid #007bff; padding-left: 10px;">
                    ${order.review.replies
                      .map(
                        (reply) => `
                      <div class="reply-item" style="margin-bottom: 5px;">
                        <strong>Seller Reply (${reply.seller_name}):</strong>
                        <p style="margin: 2px 0;">${reply.text}</p>
                        <small>Replied on: ${reply.created_at}</small>
                      </div>
                    `
                      )
                      .join("")}
                  </div>
                `
                  : ""
              }
          </div>
          `
            : ""
        }
    `;

      container.appendChild(card);
    });

    // Add event listeners for the dynamically created buttons *after* adding them to DOM
    attachButtonListeners(container);
  }

  // Helper function to attach listeners (using event delegation)
  function attachButtonListeners(container) {
    // Remove any existing event listeners to prevent duplicates
    container.removeEventListener("click", handleButtonClick);

    // Add the event listener
    container.addEventListener("click", handleButtonClick);
  }

  // Separate function for button click handling to avoid duplicate listeners
  function handleButtonClick(event) {
    // Message Button Listener
    const messageBtn = event.target.closest(".message-btn");
    if (messageBtn) {
      const orderId = messageBtn.dataset.orderId;
      const sellerId = messageBtn.dataset.sellerId;
      console.log(
        `Message button clicked: Order ${orderId}, Seller ${sellerId}`
      );
      // Call the loadMessages function
      loadMessages(orderId, sellerId);
      return; // Stop further checks
    }

    // Review Button Listener
    const reviewBtn = event.target.closest(".review-btn");
    if (reviewBtn && !reviewBtn.disabled) {
      const orderId = reviewBtn.dataset.orderId;
      const productId = reviewBtn.dataset.productId;
      console.log(
        `Review button clicked: Order ${orderId}, Product ${productId}`
      );
      // Only show review modal if there isn't one already open
      if (!activeReviewModal) {
        showReviewModal(orderId, productId);
      }
      return; // Stop further checks
    }
  }

  // Function to show review modal
  function showReviewModal(orderId, productId) {
    // If there's already an active modal, remove it first
    if (activeReviewModal) {
      activeReviewModal.remove();
      activeReviewModal = null;
    }

    const modal = document.createElement("div");
    modal.className = "review-modal";
    modal.innerHTML = `
        <div class="review-modal-content">
          <span class="close-modal">&times;</span>
          <h2>Add Review</h2>
          <form id="review-form">
            <div class="rating">
              <label>Rating:</label>
              <div class="stars">
                <i class="fas fa-star" data-rating="1"></i>
                <i class="fas fa-star" data-rating="2"></i>
                <i class="fas fa-star" data-rating="3"></i>
                <i class="fas fa-star" data-rating="4"></i>
                <i class="fas fa-star" data-rating="5"></i>
              </div>
            </div>
            <div class="form-group">
              <label for="review-text">Your Review:</label>
              <textarea id="review-text" rows="4" required></textarea>
            </div>
            <button type="submit" class="submit-review">Submit Review</button>
          </form>
        </div>
      `;

    document.body.appendChild(modal);
    activeReviewModal = modal; // Track the active modal

    // Function to close and clean up the modal
    const closeModal = () => {
      if (modal && document.body.contains(modal)) {
        document.body.removeChild(modal);
        activeReviewModal = null; // Clear the active modal reference
      }
    };

    // Close modal when clicking the close button
    const closeBtn = modal.querySelector(".close-modal");
    if (closeBtn) {
      closeBtn.addEventListener("click", closeModal, { once: true });
    }

    // Close modal when clicking outside
    modal.addEventListener(
      "click",
      (e) => {
        if (e.target === modal) {
          closeModal();
        }
      },
      { once: true }
    );

    // Handle star rating
    const stars = modal.querySelectorAll(".stars i");
    let selectedRating = 0;

    stars.forEach((star) => {
      star.addEventListener("click", () => {
        const rating = Number.parseInt(star.dataset.rating);
        selectedRating = rating;
        stars.forEach((s, index) => {
          s.style.color = index < rating ? "#ffd700" : "#ccc";
        });
      });
    });

    // Handle form submission
    const form = modal.querySelector("#review-form");
    if (form) {
      form.addEventListener(
        "submit",
        (e) => {
          e.preventDefault();
          const reviewText = document
            .getElementById("review-text")
            .value.trim();

          if (selectedRating === 0) {
            showCustomAlert("Please select a rating");
            return;
          }

          if (!reviewText) {
            showCustomAlert("Please write a review comment");
            return;
          }

          console.log("Submitting review with:", {
            order_id: orderId,
            product_id: productId,
            rating: selectedRating,
            comment: reviewText,
          });

          // Submit review to backend
          fetch("/submit-review", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              order_id: orderId,
              product_id: productId,
              rating: selectedRating,
              comment: reviewText,
            }),
          })
            .then((response) => response.json())
            .then((data) => {
              closeModal(); // Close modal before showing alert

              if (data.success) {
                showCustomAlert("Review submitted successfully!");
                // Refresh the page to show the new review
                window.location.reload();
              } else {
                showCustomAlert(data.error || "Failed to submit review");
              }
            })
            .catch((error) => {
              closeModal(); // Close modal before showing alert
              console.error("Error:", error);
              showCustomAlert("An error occurred while submitting the review");
            });
        },
        { once: true }
      ); // Use once: true to prevent multiple submissions
    }
  }

  // Handle tab clicks
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document
        .querySelectorAll(".tab-btn")
        .forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      const tab = btn.getAttribute("data-tab");
      let filteredOrders = [];

      if (tab === "all-orders") {
        filteredOrders = allOrders;
      } else if (tab === "to-ship") {
        filteredOrders = allOrders.filter(
          (o) =>
            o.state &&
            (o.state.toLowerCase() === "processing" ||
              o.state.toLowerCase() === "pending" ||
              o.state.toLowerCase() === "shipping")
        );
      } else if (tab === "returns") {
        filteredOrders = allOrders.filter(
          (o) =>
            o.state &&
            (o.state.toLowerCase() === "cancelled" ||
              o.state.toLowerCase() === "canceled" ||
              o.state.toLowerCase() === "returned" ||
              o.state.toLowerCase() === "refunded")
        );
      } else if (tab === "to-review") {
        // Updated to only show delivered orders WITHOUT reviews
        filteredOrders = allOrders.filter(
          (o) => o.state && o.state.toLowerCase() === "delivered" && !o.review // Only include orders without reviews
        );
      }

      displayOrders(filteredOrders);
    });
  });

  // Search functionality
  document
    .querySelector(".order-search button")
    .addEventListener("click", () => {
      const query = document
        .querySelector(".order-search input")
        .value.toLowerCase();
      const results = allOrders.filter((o) => {
        // Check if 'id' exists before accessing
        const idMatches = o.id && o.id.toString().includes(query); // Ensure 'id' is not undefined
        const productMatches = o.product_name.toLowerCase().includes(query);

        return productMatches || idMatches;
      });

      displayOrders(results);
    });

  // Filter by date
  document
    .querySelector(".order-filter select")
    .addEventListener("change", (e) => {
      const value = e.target.value;
      const now = new Date();
      let filteredOrders = [];

      if (value === "last-30-days") {
        const cutoff = new Date();
        cutoff.setDate(now.getDate() - 30);
        filteredOrders = allOrders.filter(
          (o) => new Date(o.order_date) >= cutoff
        );
      } else if (value === "last-6-months") {
        const cutoff = new Date();
        cutoff.setMonth(now.getMonth() - 6);
        filteredOrders = allOrders.filter(
          (o) => new Date(o.order_date) >= cutoff
        );
      } else if (value === "2023" || value === "2022") {
        filteredOrders = allOrders.filter(
          (o) => new Date(o.order_date).getFullYear().toString() === value
        );
      } else {
        // No filter
        filteredOrders = allOrders;
      }

      displayOrders(filteredOrders);
      console.log("date_filtration done");
    });

  // Helper function for status class
  function getStatusClass(state) {
    if (!state) return "";
    const status = state.toLowerCase();
    switch (status) {
      case "delivered":
      case "completed":
        return "delivered";
      case "shipped":
      case "shipping":
        return "shipped";
      case "processing":
      case "pending":
        return "processing";
      case "cancelled":
      case "canceled":
        return "cancelled";
      case "returned":
      case "refunded":
        return "returned";
      default:
        return status;
    }
  }
});

// Chat functionality moved from HTML to JS file
// These functions need to be global to be accessible from HTML

// Toggle chat visibility
function toggleChat() {
  const chatContainer = document.getElementById("chatContainer");
  const chatBackdrop = document.getElementById("chatBackdrop");
  if (chatContainer && chatBackdrop) {
    chatVisible = !chatVisible;
    chatContainer.style.display = chatVisible ? "flex" : "none";
    chatBackdrop.style.display = chatVisible ? "block" : "none";

    // Prevent scrolling when chat is open
    document.body.style.overflow = chatVisible ? "hidden" : "";
  }
}

// Send a message
function sendMessage() {
  const messageInput = document.getElementById("messageInput");
  if (!messageInput) return;

  const message = messageInput.value.trim();

  if (message && currentOrderId && currentSellerId) {
    fetch("/api/send-message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        receiver_id: currentSellerId,
        order_id: currentOrderId,
        message: message,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          messageInput.value = "";
          loadMessages(currentOrderId, currentSellerId); // Reload messages after sending
        }
      })
      .catch((error) => {
        console.error("Error sending message:", error);
      });
  }
}

// Load messages for a conversation
function loadMessages(orderId, sellerId) {
  currentOrderId = orderId;
  currentSellerId = sellerId;
  if (!chatVisible) toggleChat(); // Show chat if not already visible

  const chatMessages = document.getElementById("chatMessages");
  if (!chatMessages) return;

  fetch(`/api/get-messages/${orderId}`)
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        chatMessages.innerHTML = ""; // Clear existing messages
        data.messages.forEach((msg) => {
          const messageDiv = document.createElement("div");
          // Use currentUserId fetched in DOMContentLoaded
          messageDiv.className = `message ${
            msg.sender_id === currentUserId ? "sent" : "received"
          }`;

          const messageContent = document.createElement("div");
          messageContent.textContent = msg.message;

          const messageTime = document.createElement("div");
          messageTime.className = "message-time";
          messageTime.textContent = new Date(msg.timestamp).toLocaleString();

          messageDiv.appendChild(messageContent);
          messageDiv.appendChild(messageTime);
          chatMessages.appendChild(messageDiv);
        });
        // Scroll to the bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
      }
    })
    .catch((error) => {
      console.error("Error loading messages:", error);
    });
}

// Set up polling for new messages
setInterval(() => {
  if (chatVisible && currentOrderId && currentSellerId) {
    // Optionally only fetch if needed (e.g., check for new messages instead of full reload)
    loadMessages(currentOrderId, currentSellerId);
  }
}, 5000);
document.addEventListener("DOMContentLoaded", () => {
  // Mobile dropdown handling
  function setupMobileDropdowns() {
    // Get all dropdown elements
    const accountItem = document.querySelector(".account-item")
    const accountDropdown = document.querySelector(".account-dropdown")
    const navbar = document.getElementById("navbar")
    const headerNav = document.querySelector(".header-nav")

    // Function to close all dropdowns
    function closeAllDropdowns() {
      document.querySelectorAll(".account-dropdown").forEach((dropdown) => {
        dropdown.style.display = "none"
      })

      // Remove active class from selectors
      document.querySelectorAll(".account-item").forEach((selector) => {
        selector.classList.remove("active")
      })
    }

    // Handle account item click
    if (accountItem) {
      accountItem.addEventListener("click", function (e) {
        e.preventDefault()
        e.stopPropagation()

        // Get the dropdown within this selector
        const dropdown = this.querySelector(".account-dropdown")
        if (dropdown) {
          // Toggle display
          if (dropdown.style.display === "block") {
            dropdown.style.display = "none"
            this.classList.remove("active")
          } else {
            // Close all other dropdowns first
            closeAllDropdowns()

            // Add active class to selector
            this.classList.add("active")

            // Show dropdown
            dropdown.style.display = "block"

            // For mobile: ensure dropdown is inside navbar
            if (window.innerWidth <= 768) {
              // Make sure header nav is open
              if (headerNav) {
                headerNav.classList.add("open")
              }

              // Position dropdown inside navbar
              dropdown.style.position = "relative"
              dropdown.style.top = "0"
              dropdown.style.left = "0"
              dropdown.style.width = "100%"
            } else {
              // Position the dropdown correctly relative to the navbar
              positionDropdown(dropdown, this)
            }
          }
        }
      })
    }

    // Function to position dropdown correctly
    function positionDropdown(dropdown, parent) {
      // Get parent position
      const parentRect = parent.getBoundingClientRect()

      // Check if we're on mobile
      if (window.innerWidth <= 768) {
        // For mobile, make dropdown part of the flow
        dropdown.style.position = "relative"
        dropdown.style.top = "0"
        dropdown.style.left = "0"
        dropdown.style.width = "100%"
      } else {
        // For desktop, position absolutely
        dropdown.style.position = "absolute"
        dropdown.style.top = "100%"
        dropdown.style.left = "auto"
        dropdown.style.right = "0"

        // Make sure dropdown stays within viewport
        const dropdownRect = dropdown.getBoundingClientRect()
        const viewportWidth = window.innerWidth

        if (dropdownRect.right > viewportWidth) {
          // If dropdown extends beyond right edge, align it to the right
          dropdown.style.right = "0"
          dropdown.style.left = "auto"
        }
      }
    }

    // Close dropdowns when clicking elsewhere
    document.addEventListener("click", () => {
      closeAllDropdowns()
    })

    // Prevent dropdown clicks from closing the dropdown
    document.querySelectorAll(".account-dropdown").forEach((dropdown) => {
      dropdown.addEventListener("click", (e) => {
        e.stopPropagation()
      })
    })
  }

  // Call this function after the page loads
  setupMobileDropdowns()
  // Also call it on resize to handle orientation changes
  window.addEventListener("resize", setupMobileDropdowns)
})
