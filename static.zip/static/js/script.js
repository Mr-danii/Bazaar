document.addEventListener("DOMContentLoaded", () => {
  // Initialize categories
  const categories = [
    { id: 1, name: "Electronics", image: "/static/images/electronics.jpg" },
    { id: 2, name: "Fashion", image: "/static/images/fashion.webp" },
    { id: 3, name: "Home", image: "/static/images/home.jpg" },
    { id: 4, name: "Toys", image: "/static/images/toys.jpg" },
    { id: 5, name: "Beauty", image: "/static/images/beauty.jpg" },
    { id: 6, name: "Kitchen", image: "/static/images/kitchen-products.jpg" },
    { id: 7, name: "Sports", image: "/static/images/sports.jpeg" },
    { id: 8, name: "Books", image: "/static/images/books.webp" },
    { id: 9, name: "Gaming", image: "/static/images/gaming.jpg" },
  ];

  // Render categories in horizontal slider
  const categoriesContainer = document.getElementById("categoriesContainer");
  if (categoriesContainer) {
    categoriesContainer.innerHTML = categories
      .map(
        (category) => `
            <div class="category-card" data-category="${category.name}">
              <img src="${category.image}" alt="${category.name}" />
              <h3>${category.name}</h3>
            </div>
          `
      )
      .join("");
  }

  // Initialize products
  let allProducts = [];

  // Helper function to normalize category names for comparison
  function normalizeCategory(category) {
    return category.toLowerCase().trim();
  }

  // Fetch all products once
  fetch("/api/all-products")
    .then((res) => res.json())
    .then((products) => {
      allProducts = products;
      renderProducts(products);
      populateCategoryFilters(products);
    })
    .catch((error) => {
      console.error("Error fetching products:", error);
      // Display placeholder products if API fails
      const placeholderProducts = generatePlaceholderProducts();
      allProducts = placeholderProducts;
      renderProducts(placeholderProducts);
      populateCategoryFilters(placeholderProducts);
    });

  // Generate placeholder products for demo purposes
  function generatePlaceholderProducts() {
    return [
      {
        id: 1,
        product_name: "Wireless Bluetooth Headphones",
        price: 79.99,
        main_image: "/static/images/electronics.jpg",
        seller_name: "AudioTech",
        category: "Electronics",
      },
      {
        id: 2,
        product_name: "Men's Casual T-Shirt",
        price: 24.99,
        main_image: "/static/images/fashion.webp",
        seller_name: "FashionHub",
        category: "Fashion",
      },
      {
        id: 3,
        product_name: "Modern Coffee Table",
        price: 149.99,
        main_image: "/static/images/home.jpg",
        seller_name: "HomeDecor",
        category: "Home",
      },
      {
        id: 4,
        product_name: "Educational Building Blocks",
        price: 34.99,
        main_image: "/static/images/toys.jpg",
        seller_name: "ToyWorld",
        category: "Toys",
      },
      {
        id: 5,
        product_name: "Organic Face Serum",
        price: 29.99,
        main_image: "/static/images/beauty.jpg",
        seller_name: "NaturalBeauty",
        category: "Beauty",
      },
      {
        id: 6,
        product_name: "Stainless Steel Cookware Set",
        price: 199.99,
        main_image: "/static/images/kitchen.jpeg",
        seller_name: "KitchenPro",
        category: "Kitchen",
      },
      {
        id: 7,
        product_name: "Yoga Mat Premium",
        price: 45.99,
        main_image: "/static/images/sports.jpeg",
        seller_name: "FitLife",
        category: "Sports",
      },
      {
        id: 8,
        product_name: "Bestselling Novel Collection",
        price: 59.99,
        main_image: "/static/images/books.webp",
        seller_name: "BookWorm",
        category: "Books",
      },
    ];
  }

  // Render products in horizontal slider
  function renderProducts(products) {
    const productContainer = document.getElementById("productContainer");
    if (!productContainer) return;

    productContainer.innerHTML = "";
    if (!products.length) {
      productContainer.innerHTML = "<p>No products found.</p>";
      return;
    }

    products.forEach((product) => {
      const card = document.createElement("div");
      card.className = "product-card";
      card.setAttribute("data-category", product.category);

      card.innerHTML = `
          <div class="product-image">
            <img src="${product.main_image}" alt="${product.product_name}">
          </div>
          <div class="product-info">
            <h3>${product.product_name}</h3>
            <p class="product-price">$${product.price}</p>
            <p class="seller">Seller: ${product.seller_name}</p>
          </div>
        `;
      productContainer.appendChild(card);
    });
  }

  // Populate category filters
  function populateCategoryFilters(products) {
    const categoryFilter = document.getElementById("categoryFilter");
    if (!categoryFilter) return;

    // Clear existing filter buttons
    categoryFilter.innerHTML =
      '<button class="filter-btn active" data-category="all">All</button>';

    // Get unique categories from products
    const uniqueCategories = [...new Set(products.map((p) => p.category))];

    // Add filter buttons for each category
    uniqueCategories.forEach((category) => {
      const filterBtn = document.createElement("button");
      filterBtn.className = "filter-btn";
      filterBtn.setAttribute("data-category", category);
      filterBtn.textContent = category;
      categoryFilter.appendChild(filterBtn);
    });

    // Add event listeners to filter buttons
    document.querySelectorAll(".filter-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        // Remove active class from all buttons
        document
          .querySelectorAll(".filter-btn")
          .forEach((b) => b.classList.remove("active"));

        // Add active class to clicked button
        btn.classList.add("active");

        const selectedCategory = btn.getAttribute("data-category");

        if (selectedCategory === "all") {
          renderProducts(allProducts);
        } else {
          const filteredProducts = allProducts.filter(
            (p) =>
              normalizeCategory(p.category) ===
              normalizeCategory(selectedCategory)
          );
          renderProducts(filteredProducts);
        }
      });
    });
  }

  // Category slider navigation
  const categoryPrevBtn = document.querySelector(".prev-category");
  const categoryNextBtn = document.querySelector(".next-category");
  const categoriesContainerEl = document.getElementById("categoriesContainer");

  if (categoryPrevBtn && categoryNextBtn && categoriesContainerEl) {
    categoryPrevBtn.addEventListener("click", () => {
      categoriesContainerEl.scrollBy({
        left: -220,
        behavior: "smooth",
      });
    });

    categoryNextBtn.addEventListener("click", () => {
      categoriesContainerEl.scrollBy({
        left: 220,
        behavior: "smooth",
      });
    });
  }

  // Product slider navigation
  const productPrevBtn = document.querySelector(".prev-product");
  const productNextBtn = document.querySelector(".next-product");
  const productContainer = document.getElementById("productContainer");

  if (productPrevBtn && productNextBtn && productContainer) {
    productPrevBtn.addEventListener("click", () => {
      productContainer.scrollBy({
        left: -240,
        behavior: "smooth",
      });
    });

    productNextBtn.addEventListener("click", () => {
      productContainer.scrollBy({
        left: 240,
        behavior: "smooth",
      });
    });
  }

  // Category click handler
  document.addEventListener("click", (e) => {
    const categoryCard = e.target.closest(".category-card");
    if (categoryCard) {
      const selectedCategory = categoryCard.getAttribute("data-category");

      // Highlight selected category
      document.querySelectorAll(".category-card").forEach((card) => {
        card.classList.remove("active");
      });
      categoryCard.classList.add("active");

      // Filter products by category - FIXED: Using normalizeCategory for case-insensitive comparison
      const filteredProducts = allProducts.filter(
        (p) =>
          normalizeCategory(p.category) === normalizeCategory(selectedCategory)
      );

      renderProducts(filteredProducts);

      // Activate corresponding filter button
      document.querySelectorAll(".filter-btn").forEach((btn) => {
        btn.classList.remove("active");
        if (
          normalizeCategory(btn.getAttribute("data-category")) ===
          normalizeCategory(selectedCategory)
        ) {
          btn.classList.add("active");
        }
      });

      // Scroll to products section
      document.querySelector(".products-section").scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  });

  // Slideshow functionality
  const slides = document.querySelectorAll(".slide");
  const dots = document.querySelectorAll(".dot");
  const prevBtn = document.querySelector(".prev-slide");
  const nextBtn = document.querySelector(".next-slide");
  let currentSlide = 0;
  let slideInterval;

  // Initialize slideshow
  function startSlideshow() {
    slideInterval = setInterval(nextSlide, 5000);
  }

  // Show specific slide
  function showSlide(index) {
    // Hide all slides
    slides.forEach((slide) => {
      slide.classList.remove("active");
    });

    // Remove active class from all dots
    dots.forEach((dot) => {
      dot.classList.remove("active");
    });

    // Show the selected slide and activate corresponding dot
    slides[index].classList.add("active");
    dots[index].classList.add("active");

    // Update current slide index
    currentSlide = index;
  }

  // Next slide function
  function nextSlide() {
    let next = currentSlide + 1;
    if (next >= slides.length) {
      next = 0;
    }
    showSlide(next);
  }

  // Previous slide function
  function prevSlide() {
    let prev = currentSlide - 1;
    if (prev < 0) {
      prev = slides.length - 1;
    }
    showSlide(prev);
  }

  // Event listeners for controls
  if (prevBtn && nextBtn) {
    prevBtn.addEventListener("click", () => {
      clearInterval(slideInterval);
      prevSlide();
      startSlideshow();
    });

    nextBtn.addEventListener("click", () => {
      clearInterval(slideInterval);
      nextSlide();
      startSlideshow();
    });
  }

  // Dot navigation
  if (dots.length > 0) {
    dots.forEach((dot, index) => {
      dot.addEventListener("click", () => {
        clearInterval(slideInterval);
        showSlide(index);
        startSlideshow();
      });
    });
  }

  // Start the slideshow if slides exist
  if (slides.length > 0) {
    startSlideshow();
  }

  // Reviews Slider Functionality
  const slider = document.querySelector(".reviews-slider");
  const reviewPrevBtn = document.querySelector(".reviews-section .prev-btn");
  const reviewNextBtn = document.querySelector(".reviews-section .next-btn");
  const reviewDots = document.querySelectorAll(".review-dot");
  let currentPosition = 0;

  // Display placeholder reviews
  function displayPlaceholderReviews() {
    const reviewsContainer = document.querySelector(".reviews-slider");
    if (!reviewsContainer) return;

    const placeholderReviews = [
      {
        customer_name: "John D.",
        product_name: "Wireless Headphones",
        rating: 5,
        comment:
          "Absolutely love these headphones! The sound quality is amazing and battery life is impressive.",
      },
      {
        customer_name: "Sarah M.",
        product_name: "Kitchen Blender",
        rating: 4,
        comment:
          "Great product for the price. Makes smoothies in seconds and easy to clean.",
      },
      {
        customer_name: "Michael T.",
        product_name: "Fitness Tracker",
        rating: 5,
        comment:
          "This tracker has changed my fitness routine. Accurate measurements and the app is intuitive.",
      },
      {
        customer_name: "Emily R.",
        product_name: "Coffee Maker",
        rating: 4,
        comment:
          "Makes delicious coffee and looks great on my counter. Would recommend!",
      },
    ];

    reviewsContainer.innerHTML = placeholderReviews
      .map(
        (review) => `
            <div class="review-card">
              <div class="review-header">
                <div class="reviewer-avatar">
                  ${review.customer_name.charAt(0).toUpperCase()}
                </div>
                <div class="reviewer-info">
                  <h4>${review.customer_name}</h4>
                  <p>${review.product_name}</p>
                </div>
              </div>
              <div class="review-rating">
                ${"★".repeat(review.rating)}${"☆".repeat(5 - review.rating)}
              </div>
              <p class="review-text">"${review.comment}"</p>
            </div>
          `
      )
      .join("");
  }

  // Fetch and display reviews
  fetch("/api/random-reviews")
    .then((res) => res.json())
    .then((data) => {
      if (data.success && data.reviews) {
        const reviewsContainer = document.querySelector(".reviews-slider");
        reviewsContainer.innerHTML = data.reviews
          .map(
            (review) => `
                <div class="review-card">
                  <div class="review-header">
                    <div class="reviewer-avatar">
                      ${review.customer_name.charAt(0).toUpperCase()}
                    </div>
                    <div class="reviewer-info">
                      <h4>${review.customer_name}</h4>
                      <p>${review.product_name}</p>
                    </div>
                  </div>
                  <div class="review-rating">
                    ${"★".repeat(review.rating)}${"☆".repeat(5 - review.rating)}
                  </div>
                  <p class="review-text">"${review.comment}"</p>
                </div>
              `
          )
          .join("");
      } else {
        // Display placeholder reviews if API fails
        displayPlaceholderReviews();
      }

      // Initialize slider controls after reviews are loaded
      initReviewSlider();
    })
    .catch((error) => {
      console.error("Error fetching reviews:", error);
      displayPlaceholderReviews();
      initReviewSlider();
    });

  function initReviewSlider() {
    if (!slider || !reviewPrevBtn || !reviewNextBtn) return;

    const reviewCards = document.querySelectorAll(".review-card");
    if (reviewCards.length === 0) return;

    // Set width for proper sliding
    const cardWidth = 350; // Width of card + gap

    // Slider navigation
    reviewPrevBtn.addEventListener("click", () => {
      currentPosition = Math.min(currentPosition + cardWidth, 0);
      slider.style.transform = `translateX(${currentPosition}px)`;
      updateActiveDot();
    });

    reviewNextBtn.addEventListener("click", () => {
      const maxScroll = -(reviewCards.length * cardWidth - cardWidth);
      currentPosition = Math.max(currentPosition - cardWidth, maxScroll);
      slider.style.transform = `translateX(${currentPosition}px)`;
      updateActiveDot();
    });

    // Update active dot based on current position
    function updateActiveDot() {
      const activeIndex = Math.abs(Math.round(currentPosition / cardWidth));
      reviewDots.forEach((dot, index) => {
        dot.classList.toggle("active", index === activeIndex);
      });
    }

    // Dot navigation
    reviewDots.forEach((dot, index) => {
      dot.addEventListener("click", () => {
        currentPosition = -(index * cardWidth);
        slider.style.transform = `translateX(${currentPosition}px)`;
        updateActiveDot();
      });
    });
  }

  // Sticky navbar with hide-on-scroll functionality
  let lastScrollTop = 0;
  window.addEventListener("scroll", () => {
    const currentScroll =
      window.pageYOffset || document.documentElement.scrollTop;
    const navbar = document.getElementById("navbar");

    if (currentScroll > lastScrollTop && currentScroll > 100) {
      // Scrolling down
      navbar.classList.add("navbar-hidden");
    } else {
      // Scrolling up
      navbar.classList.remove("navbar-hidden");
    }
    lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
  });

  // Shop Now button functionality - redirect to login page
  document.querySelectorAll(".cta-button").forEach((button) => {
    button.addEventListener("click", (e) => {
      e.preventDefault();
      window.location.href = "/login";
    });
  });
});
