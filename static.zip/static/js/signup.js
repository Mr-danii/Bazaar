// Password validation function
function validatePassword() {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const address = document.getElementById('address').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Check if all fields are filled
    if (name === "" || email === "" || phone === "" || address === "" || password === "" || confirmPassword === "") {
        alert("Please fill in all fields.");
        return false; // Prevent form submission
    }

    // Password Regex (at least 8 characters, one number, one special character)
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    // Check password strength
    if (!password.match(passwordRegex)) {
        alert("Password must be at least 8 characters long and contain a number, a special character, and both uppercase and lowercase letters.");
        return false; // Prevent form submission
    }

    // Check if passwords match
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false; // Prevent form submission
    }

    // Phone number regex (example: 10 digits)
    const phoneRegex = /^[0-9]{11}$/;
    if (!phone.match(phoneRegex)) {
        alert("Please enter a valid 10-digit phone number.");
        return false; // Prevent form submission
    }

    return true; // Validation passed, allow form submission
}
