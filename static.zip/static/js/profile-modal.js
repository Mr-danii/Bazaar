document.addEventListener("DOMContentLoaded", () => {
  // Fetch user data from the API
  fetch("/api/get-current-user")
    .then((response) => {
      // If the API endpoint doesn't exist in your demo, handle the error
      if (!response.ok) {
        // Use mock data for demo purposes
        return Promise.resolve({
          success: true,
          user: {
            name: "Demo User",
            email: "user@example.com",
            role: "Buyer",
            phone: "+1 234 567 8900",
            address: "123 Main St, City",
          },
        });
      }
      return response.json();
    })
    .then((data) => {
      if (data.success) {
        const user = data.user;

        // Update the account dropdown with user information
        const accountDropdown = document.getElementById("accountDropdown");
        if (accountDropdown) {
          accountDropdown.innerHTML = `
                <div class="user-info">
                  <div class="user-name">${user.name}</div>
                  <div class="user-email">${user.email}</div>
                  <div class="user-role">${user.role}</div>
                </div>
                <ul>
                  
                  
                  <li>
                    <a href="#" id="logoutButton">
                      <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                  </li>
                </ul>
              `;

          // Add event listener to logout button
          const logoutButton = document.getElementById("logoutButton");
          if (logoutButton) {
            logoutButton.addEventListener("click", (e) => {
              e.preventDefault();
              logout();
            });
          }
        }
      } else {
        console.error("Failed to fetch user data:", data.error);
      }
    })
    .catch((error) => {
      console.error("Error fetching user data:", error);
    });
});

// Function to handle logout
function logout() {
  // Redirect to logout endpoint
  window.location.href = "/logout";
}
