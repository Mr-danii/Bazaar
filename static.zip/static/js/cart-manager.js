// Function to check session status
async function checkSession() {
  try {
    const response = await fetch("/api/check-session", {
      credentials: "include",
    });
    const data = await response.json();
    if (!data.success) {
      window.location.href = "/login";
      return false;
    }
    return true;
  } catch (error) {
    console.error("Error checking session:", error);
    window.location.href = "/login";
    return false;
  }
}

// Function to fetch cart details and update the page
async function fetchCartDetails() {
  try {
    // Check session first
    const isLoggedIn = await checkSession();
    if (!isLoggedIn) return;

    // Make an API call to fetch the cart details
    const response = await fetch("/api/cart-details");
    const data = await response.json();

    if (data.error) {
      showNotification("Error: " + data.error, "error");
      return;
    }

    const cartItemsContainer = document.getElementById("cartItemsContainer");
    const cartItemCount = document.getElementById("cartItemCount");
    const cartTotal = document.getElementById("cartTotal");
    const cartBadge = document.getElementById("cart-badge");
    const checkoutBtn = document.querySelector(".checkout-btn");

    if (!cartItemsContainer || !cartItemCount || !cartTotal) {
      console.error("Required DOM elements not found");
      return;
    }

    cartItemsContainer.innerHTML = ""; // Clear existing cart items

    let totalAmount = 0;
    let itemCount = 0;

    // Check if cart is empty
    if (!data.cart_items || data.cart_items.length === 0) {
      // Show empty cart message with larger text and icon
      cartItemsContainer.innerHTML = `
        <div class="empty-cart">
          <i class="fas fa-shopping-cart"></i>
          <p>Your cart is empty</p>
        </div>
      `;

      // Disable checkout button
      if (checkoutBtn) checkoutBtn.disabled = true;

      // Update localStorage to reflect empty cart
      localStorage.setItem("bazaar_cart", JSON.stringify([]));

      // Broadcast the update to other components
      broadcastCartUpdate();
    } else {
      // Enable checkout button
      if (checkoutBtn) checkoutBtn.disabled = false;

      // Loop through cart items and create HTML elements for each
      data.cart_items.forEach((item) => {
        itemCount += item.quantity;
        totalAmount += item.total_price;

        const cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");
        cartItem.setAttribute("data-item-id", item.cart_id);

        // Store original USD price as a data attribute
        const originalPrice = item.price;

        // Get current currency symbol and convert price
        const symbol = window.currentSymbol || "$";
        const convertedPrice = convertPrice(originalPrice);

        cartItem.innerHTML = `
          <img src="${item.image}" alt="${item.name}" class="product-img" />
          <div class="product-details">
            <h3>${item.name}</h3>
            <p class="price" data-original-price="${originalPrice}">${symbol}${convertedPrice}</p>
            <p class="stock">In Stock</p>
            <div class="controls-container">
              <div class="quantity-controls">
                <span>${item.quantity}</span>
              </div>
              <button class="remove-btn">
                <img src="${getStaticUrl("images/bin.png")}" alt="Remove" />
              </button>
            </div>
          </div>
        `;

        cartItemsContainer.appendChild(cartItem);
      });

      // Update localStorage with current cart data
      const cartData = data.cart_items.map((item) => ({
        id: item.cart_id,
        name: item.name,
        price: item.price,
        image: item.image,
        quantity: item.quantity,
      }));
      localStorage.setItem("bazaar_cart", JSON.stringify(cartData));

      // Broadcast the update to other components
      broadcastCartUpdate();
    }

    // Update the item count and total price
    cartItemCount.textContent = itemCount;
    if (cartBadge) cartBadge.textContent = itemCount;

    // Store original USD total as a data attribute
    const originalTotal = totalAmount.toFixed(2);

    // Get current currency symbol and convert total
    const symbol = window.currentSymbol || "$";
    const convertedTotal = convertPrice(originalTotal);

    // Update cart total with data attribute for original price
    cartTotal.setAttribute("data-original-total", originalTotal);
    cartTotal.textContent = `${symbol}${convertedTotal}`;

    // Add event listeners to remove buttons
    setupRemoveButtons();
  } catch (error) {
    console.error("Error fetching cart details:", error);
    showNotification("Error loading cart items", "error");
  }
}

// Function to remove a cart item
async function removeCartItem(itemId) {
  try {
    const response = await fetch(`/api/remove-cart-entry/${itemId}`, {
      method: "DELETE",
    });

    const data = await response.json();

    if (data.success) {
      // Remove item from localStorage immediately
      let cartData = JSON.parse(localStorage.getItem("bazaar_cart") || "[]");
      cartData = cartData.filter((item) => item.id !== itemId);
      localStorage.setItem("bazaar_cart", JSON.stringify(cartData));

      // Update cart badge immediately
      updateCartBadges(cartData);

      // Broadcast the update to other components
      broadcastCartUpdate();

      // Show notification instead of alert
      showNotification("The product has been removed from cart");

      // Re-fetch cart details after removal
      fetchCartDetails();
    } else {
      showNotification("Failed to remove item", "error");
    }
  } catch (error) {
    console.error("Error removing cart item:", error);
    showNotification("Error removing item from cart", "error");
  }
}

// Place order function
function placeOrder() {
  // Instead of showing a confirm dialog, directly open the payment modal
  // The payment modal will handle the order placement
  const event = new CustomEvent("openPaymentModal");
  window.dispatchEvent(event);
}

// Helper function to get static URL for Flask templates
function getStaticUrl(path) {
  // In a real Flask app, this would use url_for
  // For this example, we'll just return a simple path
  return `/static/${path}`;
}

// Initialize the cart
document.addEventListener("DOMContentLoaded", () => {
  // Sync cart data from localStorage first
  syncCartFromLocalStorage();

  // Then fetch cart details from server
  fetchCartDetails();

  // Add event listener to checkout button
  const checkoutBtn = document.querySelector(".checkout-btn");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", placeOrder);
  }

  // Listen for storage events (changes to localStorage from other pages)
  window.addEventListener("storage", (event) => {
    if (event.key === "bazaar_cart") {
      // Cart was updated in another tab/window
      syncCartFromLocalStorage();
    }
  });
});

// Function to sync cart data from localStorage
function syncCartFromLocalStorage() {
  const cartData = JSON.parse(localStorage.getItem("bazaar_cart") || "[]");
  updateCartBadges(cartData);
}

// Function to update all cart badges on the page
function updateCartBadges(cartData) {
  const cartBadge = document.getElementById("cart-badge");
  const cartItemCount = document.getElementById("cartItemCount");

  const totalItems = cartData.reduce((total, item) => total + item.quantity, 0);

  if (cartBadge) {
    cartBadge.textContent = totalItems;
  }

  if (cartItemCount) {
    cartItemCount.textContent = totalItems;
  }
}

// Function to broadcast cart updates to other components on the same page
function broadcastCartUpdate() {
  const event = new CustomEvent("cartUpdated");
  window.dispatchEvent(event);
}

////////////////////////////////
// Currency conversion rates (relative to USD)
const exchangeRates = {
  USD: 1,
  EUR: 0.92,
  SAR: 3.75, // Saudi Riyal
  PKR: 278.5, // Pakistani Rupee
};

// Currency symbols
const currencySymbols = {
  USD: "$",
  EUR: "€",
  SAR: "﷼", // Saudi Riyal symbol
  PKR: "₨", // Pakistani Rupee symbol
};

// Make these available globally
window.exchangeRates = exchangeRates;
window.currencySymbols = currencySymbols;

// Current currency
window.currentCurrency = "USD";
window.currentSymbol = "$";

// Initialize currency conversion
document.addEventListener("DOMContentLoaded", () => {
  setupCurrencySelector();
});

// Setup currency selector
function setupCurrencySelector() {
  const currencyItems = document.querySelectorAll(".currency-dropdown a");
  const currentCurrencyElement = document.getElementById("current-currency");

  currencyItems.forEach((item) => {
    item.addEventListener("click", function (e) {
      e.preventDefault();

      // Get currency data
      const newCurrency = this.getAttribute("data-currency");
      const newSymbol = this.getAttribute("data-symbol");

      // Update current currency
      window.currentCurrency = newCurrency;
      window.currentSymbol = newSymbol;

      // Update display
      currentCurrencyElement.textContent = newCurrency;

      // Update currency icon
      updateCurrencyIcon(newCurrency);

      // Update prices if cart has items
      updatePrices();
    });
  });
}

// Update currency icon
function updateCurrencyIcon(currency) {
  const iconElement = document.querySelector(
    ".currency-selector a i:first-child"
  );

  // Remove all existing classes
  iconElement.className = "";

  // Add appropriate icon class
  switch (currency) {
    case "USD":
      iconElement.className = "fas fa-dollar-sign";
      break;
    case "EUR":
      iconElement.className = "fas fa-euro-sign";
      break;
    case "SAR":
      iconElement.className = "fas fa-money-bill-wave"; // Using money bill for SAR
      break;
    case "PKR":
      iconElement.className = "fas fa-rupee-sign"; // Using rupee sign as closest to PKR
      break;
    default:
      iconElement.className = "fas fa-dollar-sign";
  }
}

// Convert price based on selected currency
function convertPrice(priceInUSD) {
  if (!priceInUSD || isNaN(priceInUSD)) return "0.00";

  const rate = exchangeRates[window.currentCurrency] || 1;
  const convertedPrice = Number.parseFloat(priceInUSD) * rate;

  return convertedPrice.toFixed(2);
}

// Update all prices in the cart
function updatePrices() {
  // Update individual item prices
  const priceElements = document.querySelectorAll(".price");
  priceElements.forEach((element) => {
    // Get the original price from data attribute
    const originalPrice = element.getAttribute("data-original-price");
    if (originalPrice) {
      // Update with new currency and converted price
      element.textContent = `${window.currentSymbol}${convertPrice(
        originalPrice
      )}`;
    }
  });

  // Update cart total
  const cartTotalElement = document.getElementById("cartTotal");
  if (cartTotalElement) {
    // Get the original total from data attribute
    const originalTotal = cartTotalElement.getAttribute("data-original-total");
    if (originalTotal) {
      // Update with new currency and converted total
      cartTotalElement.textContent = `${window.currentSymbol}${convertPrice(
        originalTotal
      )}`;
    }
  }
}

// Add this function to show notifications
function showNotification(message, type = "success") {
  // Check if notification element exists, create if not
  let notification = document.querySelector(".notification");
  if (!notification) {
    notification = document.createElement("div");
    notification.className = "notification";
    notification.innerHTML = `
      <div class="notification-content">
        <i class="fas fa-check-circle"></i>
        <span id="notification-message"></span>
      </div>
    `;
    document.body.appendChild(notification);
  }

  const notificationMessage = document.getElementById("notification-message");
  notificationMessage.textContent = message;
  notification.className = `notification ${type}`;
  notification.classList.add("show");

  // Hide notification after 3 seconds
  setTimeout(() => {
    notification.classList.remove("show");
  }, 3000);
}

// Add this function to set up remove buttons
function setupRemoveButtons() {
  const removeButtons = document.querySelectorAll(".remove-btn");
  removeButtons.forEach((button) => {
    // Remove existing event listeners
    const newButton = button.cloneNode(true);
    button.parentNode.replaceChild(newButton, button);

    // Add new event listener
    newButton.addEventListener("click", async (event) => {
      const cartItem = newButton.closest(".cart-item");
      if (cartItem) {
        const itemId = cartItem.getAttribute("data-item-id");
        await removeCartItem(itemId);
      }
    });
  });
}

// Make these functions available globally
window.updatePrices = updatePrices;
window.syncCartFromLocalStorage = syncCartFromLocalStorage;
window.broadcastCartUpdate = broadcastCartUpdate;
window.convertPrice = convertPrice;


document.addEventListener("DOMContentLoaded", () => {
  // Mobile dropdown handling
  function setupMobileDropdowns() {
    // Get all dropdown elements
    const currencySelector = document.querySelector(".currency-selector")
    const accountItem = document.querySelector(".account-item")
    const currencyDropdown = document.querySelector(".currency-dropdown")
    const accountDropdown = document.querySelector(".account-dropdown")
    const navbar = document.getElementById("navbar")
    const headerNav = document.querySelector(".header-nav")

    // Function to close all dropdowns
    function closeAllDropdowns() {
      document.querySelectorAll(".currency-dropdown, .account-dropdown").forEach((dropdown) => {
        dropdown.style.display = "none"
      })

      // Remove active class from selectors
      document.querySelectorAll(".currency-selector, .account-item").forEach((selector) => {
        selector.classList.remove("active")
      })
    }

    // Handle currency selector click
    if (currencySelector) {
      currencySelector.addEventListener("click", function (e) {
        e.preventDefault()
        e.stopPropagation()

        // Get the dropdown within this selector
        const dropdown = this.querySelector(".currency-dropdown")
        if (dropdown) {
          // Toggle display
          if (dropdown.style.display === "block") {
            dropdown.style.display = "none"
            this.classList.remove("active")
          } else {
            // Close all other dropdowns first
            closeAllDropdowns()

            // Add active class to selector
            this.classList.add("active")

            // Show dropdown
            dropdown.style.display = "block"

            // For mobile: ensure dropdown is inside navbar
            if (window.innerWidth <= 768) {
              // Make sure header nav is open
              if (headerNav) {
                headerNav.classList.add("open")
              }

              // Position dropdown inside navbar
              dropdown.style.position = "relative"
              dropdown.style.top = "0"
              dropdown.style.left = "0"
              dropdown.style.width = "100%"
            } else {
              // Position the dropdown correctly relative to the navbar
              positionDropdown(dropdown, this)
            }
          }
        }
      })
    }

    // Handle account item click
    if (accountItem) {
      accountItem.addEventListener("click", function (e) {
        e.preventDefault()
        e.stopPropagation()

        // Get the dropdown within this selector
        const dropdown = this.querySelector(".account-dropdown")
        if (dropdown) {
          // Toggle display
          if (dropdown.style.display === "block") {
            dropdown.style.display = "none"
            this.classList.remove("active")
          } else {
            // Close all other dropdowns first
            closeAllDropdowns()

            // Add active class to selector
            this.classList.add("active")

            // Show dropdown
            dropdown.style.display = "block"

            // For mobile: ensure dropdown is inside navbar
            if (window.innerWidth <= 768) {
              // Make sure header nav is open
              if (headerNav) {
                headerNav.classList.add("open")
              }

              // Position dropdown inside navbar
              dropdown.style.position = "relative"
              dropdown.style.top = "0"
              dropdown.style.left = "0"
              dropdown.style.width = "100%"
            } else {
              // Position the dropdown correctly relative to the navbar
              positionDropdown(dropdown, this)
            }
          }
        }
      })
    }

    // Function to position dropdown correctly
    function positionDropdown(dropdown, parent) {
      // Get parent position
      const parentRect = parent.getBoundingClientRect()

      // Check if we're on mobile
      if (window.innerWidth <= 768) {
        // For mobile, make dropdown part of the flow
        dropdown.style.position = "relative"
        dropdown.style.top = "0"
        dropdown.style.left = "0"
        dropdown.style.width = "100%"
      } else {
        // For desktop, position absolutely
        dropdown.style.position = "absolute"
        dropdown.style.top = "100%"
        dropdown.style.left = "auto"
        dropdown.style.right = "0"

        // Make sure dropdown stays within viewport
        const dropdownRect = dropdown.getBoundingClientRect()
        const viewportWidth = window.innerWidth

        if (dropdownRect.right > viewportWidth) {
          // If dropdown extends beyond right edge, align it to the right
          dropdown.style.right = "0"
          dropdown.style.left = "auto"
        }
      }
    }

    // Close dropdowns when clicking elsewhere
    document.addEventListener("click", () => {
      closeAllDropdowns()
    })

    // Prevent dropdown clicks from closing the dropdown
    document.querySelectorAll(".currency-dropdown, .account-dropdown").forEach((dropdown) => {
      dropdown.addEventListener("click", (e) => {
        e.stopPropagation()
      })
    })
  }

  // Call this function after the page loads
  setupMobileDropdowns()
  // Also call it on resize to handle orientation changes
  window.addEventListener("resize", setupMobileDropdowns)
})

// Add this script to the page
document.addEventListener("DOMContentLoaded", () => {
  // Check if the script is already loaded
  if (!window.dropdownsInitialized) {
    // Create script element
    const script = document.createElement("script")
    script.src = "{{ url_for('static', filename='js/cart-dropdown.js') }}"
    document.body.appendChild(script)
    window.dropdownsInitialized = true
  }
})
